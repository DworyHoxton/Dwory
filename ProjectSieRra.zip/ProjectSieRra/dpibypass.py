#!/usr/bin/env python3
"""
Project : SieRra - DPI atlatma araci (Windows 10/11 + macOS 12.7.6+)

Windows -> paket modu (pydivert/WinDivert): sistem genelinde calisir.
           TLS ClientHello parcalama, istege bagli sahte paket (dusuk TTL),
           HTTP Host basligi karisik harf.
macOS   -> proxy modu: yerel HTTP proxy, ClientHello parcalama + DoH.
           --system-proxy ile macOS sistem proxy'sini otomatik ayarlar.

Kurulum (Windows):  pip install pydivert   (Yonetici terminal gerekir)
Kurulum (macOS):    pip install certifi   (DoH sertifika dogrulamasi icin)
                    GUI icin: run.command / build_mac.command

Ornekler:
  python dpibypass.py                       # isletim sistemine gore otomatik
  python dpibypass.py --profile guclu      # hafif|dengeli|guclu|maksimum
  python dpibypass.py --profile maksimum --no-quic
  python dpibypass.py --mode proxy --system-proxy      # macOS
  python dpibypass.py --diagnose                       # DNS / SNI / IP tanisi
  python dpibypass.py --autotune                       # macOS: calisan yontemi bul
  python dpibypass.py --mode proxy --system-proxy --app-dns   # macOS: Roblox uygulamasi dahil
  python dpibypass.py --cleanup-dns                    # macOS: artik DNS kayitlarini sil
"""
import argparse
import asyncio
import base64
import ctypes
import ipaddress
import json
import os
import platform
import shlex
import shutil
import socket
import ssl
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from concurrent.futures import (FIRST_COMPLETED, Future,
                                ThreadPoolExecutor, wait)
from urllib.parse import urlparse

SYSTEM = platform.system()

# ----------------------------------------------------------------------------
# Ortak: TLS ClientHello icinde SNI konumunu bul
# ----------------------------------------------------------------------------


def find_sni(p):
    """(isim_baslangici, isim_uzunlugu) dondurur; bulunamazsa None."""
    try:
        i = 43  # kayit(5) + el sikisma basligi(4) + surum(2) + random(32)
        i += 1 + p[i]                                   # session id
        i += 2 + struct.unpack_from("!H", p, i)[0]      # cipher suites
        i += 1 + p[i]                                   # compression
        end = i + 2 + struct.unpack_from("!H", p, i)[0]
        i += 2
        while i + 4 <= end:
            t, ln = struct.unpack_from("!HH", p, i)
            i += 4
            if t == 0:  # server_name
                nl = struct.unpack_from("!H", p, i + 3)[0]
                return i + 5, nl
            i += ln
    except Exception:
        pass
    return None


# ----------------------------------------------------------------------------
# WINDOWS: paket modu (pydivert)
# ----------------------------------------------------------------------------

HTTP_METHODS = (b"GET ", b"POST ", b"HEAD ", b"PUT ", b"OPTIONS ")
DNS_POOL = ThreadPoolExecutor(max_workers=32)
LOCAL_SUFFIXES = (".local", ".lan", ".home", ".home.arpa", ".localdomain")
RST_WINDOW = 8.0   # ClientHello'dan sonra bu kadar sn icindeki sahte RST'ler dusurulur
DOH_IPS = {"1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4", "9.9.9.9",
           "149.112.112.112"}  # DoH trafigine mudahale edilmez

STATS = {"hello": 0, "fake": 0, "rst": 0, "dns": 0, "dnsdrop": 0, "quic": 0,
         "conn": 0, "err": 0,   # conn/err: proxy modu (macOS)
         "up": 0, "down": 0}    # proxy/role uzerinden gecen bayt
_flows = {}   # (istemci ip, port, sunucu ip, port) -> ClientHello zamani
_hops = {}    # sunucu ip -> tahmini adim sayisi (SYN-ACK TTL'inden)

# Guc seviyeleri. "ttl" sahtesi otomatik hesaplanir (fake_ttl=0): sunucuya
# ulasmayacak sekilde SYN-ACK'ten olculen mesafenin 2 eksigi kullanilir.
PROFILES = {
    "hafif":    dict(split=0, reverse=False, fakes=(), fake_ttl=0),
    "dengeli":  dict(split=2, reverse=True, fakes=("badsum",), fake_ttl=0),
    "guclu":    dict(split=2, reverse=True, fakes=("badsum", "badseq"), fake_ttl=0),
    "maksimum": dict(split=2, reverse=True,
                     fakes=("badsum", "badseq", "ttl"), fake_ttl=0),
}


def make_args(profile="dengeli", **over):
    cfg = dict(PROFILES.get(profile, PROFILES["dengeli"]))
    cfg.update(strategy=strategy_for(profile))   # proxy modu (macOS)
    cfg.update(dns=True, rst_drop=True, block_quic=True, host="127.0.0.1",
               port=8080, doh=DOH_URL, delay=0.05, system_proxy=False,
               app_dns=False)
    cfg.update(over)
    h = urlparse(cfg["doh"]).hostname
    if h:
        DOH_IPS.add(h)
    return argparse.Namespace(**cfg)


def make_filter(dns=True, rst=True, quic=True):
    parts = ["(tcp and tcp.PayloadLength > 0 and "
             "(tcp.DstPort == 443 or tcp.DstPort == 80))"]
    if dns:
        parts.append("(udp and udp.DstPort == 53)")
    if quic:
        parts.append("(udp and udp.DstPort == 443)")
    out = "outbound and ip and (" + " or ".join(parts) + ")"
    # gelen: SYN-ACK (mesafe olcumu) ve istege bagli RST (DPI'in enjekte ettikleri)
    cond = "(tcp.Syn and tcp.Ack)" + (" or tcp.Rst" if rst else "")
    return f"({out}) or (inbound and ip and tcp and tcp.SrcPort == 443 and ({cond}))"


def guess_hops(ttl):
    init = 64 if ttl <= 64 else 128 if ttl <= 128 else 255
    return init - ttl


def flush_dns():
    """Windows DNS onbellegindeki zehirli kayitlari temizle."""
    if SYSTEM == "Windows":
        try:
            subprocess.run(["ipconfig", "/flushdns"], capture_output=True,
                           creationflags=0x08000000)
        except Exception:
            pass


def parse_dns_query(raw):
    """IPv4/UDP DNS paketinden (ad, tip, sinif, ihl, soru_sonu); sorgu degilse None."""
    ihl = (raw[0] & 0x0F) * 4
    dns = raw[ihl + 8:]
    if len(dns) < 17:
        return None
    flags, qd = struct.unpack_from("!HH", dns, 2)
    if flags & 0x8000 or qd != 1:
        return None
    i, labels = 12, []
    while True:
        ln = dns[i]
        if ln == 0:
            i += 1
            break
        if ln & 0xC0:
            return None
        labels.append(dns[i + 1:i + 1 + ln].decode("ascii"))
        i += 1 + ln
    qtype, qclass = struct.unpack_from("!HH", dns, i)
    return ".".join(labels).lower(), qtype, qclass, ihl, i + 4


def make_dns_reply(raw, ihl, qend, ips):
    """Sorguya karsilik, adresleri ters cevrilmis IPv4/UDP yanit paketi (bytes)."""
    dns = raw[ihl + 8:]
    flags = 0x8180 if dns[2] & 0x01 else 0x8080
    body = struct.pack("!HHHHHH", struct.unpack_from("!H", dns, 0)[0],
                       flags, 1, len(ips), 0, 0) + dns[12:qend]
    for ip in ips:
        body += (b"\xc0\x0c" + struct.pack("!HHIH", 1, 1, 120, 4)
                 + socket.inet_aton(ip))
    ip_hdr = bytearray(raw[:ihl])
    ip_hdr[12:16] = raw[16:20]
    ip_hdr[16:20] = raw[12:16]
    ip_hdr[8] = 64
    struct.pack_into("!H", ip_hdr, 2, ihl + 8 + len(body))
    udp = (raw[ihl + 2:ihl + 4] + raw[ihl:ihl + 2]
           + struct.pack("!HH", 8 + len(body), 0))
    return bytes(ip_hdr) + udp + body


def handle_dns(w, pkt):
    """DNS sorgusunu DoH ile coz.

    DoH ulasilamazsa sorgu operatorun DNS'ine BIRAKILMAZ (zehirli yanit
    sertifika hatasi verir); dusurulur ve isletim sistemi tekrar dener. Yalniz
    DoH tamamen kapaliysa (art arda 6 basarisizlik) 30 sn gecis serbest kalir.
    """
    try:
        import pydivert
        from pydivert.consts import Direction
        raw = bytes(pkt.raw)
        q = parse_dns_query(raw)
        if q is None:
            w.send(pkt)
            return
        name, qtype, qclass, ihl, qend = q
        local = "." not in name or name.endswith(LOCAL_SUFFIXES)
        if qclass != 1 or qtype not in (1, 28) or local:
            w.send(pkt)
            return
        if qtype == 28:  # AAAA: bos yanit, tarayici IPv4'e duser
            ips = []
        else:
            ips = cached_doh(name)
            if ips is None:
                now = time.time()
                _fail["n"] += 1
                if _fail["n"] >= 6:
                    _fail["n"] = 0
                    _fail["until"] = now + 30
                if now < _fail["until"]:
                    w.send(pkt)
                else:
                    STATS["dnsdrop"] += 1
                return
            _fail["n"] = 0
        reply = make_dns_reply(raw, ihl, qend, ips[:8])
        w.send(pydivert.Packet(memoryview(bytearray(reply)),
                               pkt.interface, Direction.INBOUND))
        STATS["dns"] += 1
    except Exception:
        try:
            w.send(pkt)
        except Exception:
            pass


def build(pkt, payload, seq_add=0, ttl=None, clear_psh=False):
    """Orijinal paketin IP+TCP basligini kopyalayip yeni payload ile paket uret."""
    import pydivert
    raw = bytes(pkt.raw)
    ihl = (raw[0] & 0x0F) * 4
    thl = (raw[ihl + 12] >> 4) * 4
    hdr = bytearray(raw[:ihl + thl])
    struct.pack_into("!H", hdr, 2, len(hdr) + len(payload))  # IP toplam uzunluk
    seq = struct.unpack_from("!I", hdr, ihl + 4)[0]
    struct.pack_into("!I", hdr, ihl + 4, (seq + seq_add) & 0xFFFFFFFF)
    if ttl:
        hdr[8] = ttl
    if clear_psh:
        hdr[ihl + 13] &= ~0x08
    return pydivert.Packet(memoryview(bytearray(hdr + payload)),
                           pkt.interface, pkt.direction)


def send_fakes(w, pkt, fake, a):
    """DPI'in gorup sunucunun kabul etmeyecegi sahte paketler (gercek veriden once)."""
    for kind in a.fakes:
        if kind == "ttl":      # yolda olur, sunucuya ulasmaz
            hops = _hops.get(pkt.dst_addr)
            ttl = a.fake_ttl or (max(2, hops - 2) if hops and hops > 4 else 0)
            if not ttl:        # mesafe bilinmiyor: sunucuya ulasma riski var, atla
                continue
            w.send(build(pkt, fake, 0, ttl=ttl))
        elif kind == "badsum":  # bozuk TCP checksum: sunucu atar
            f = build(pkt, fake, 0)
            f.recalculate_checksums()
            ihl = (bytes(f.raw[:1])[0] & 0x0F) * 4
            f.raw[ihl + 16] ^= 0xFF
            w.send(f, recalculate_checksum=False)
        elif kind == "badseq":  # pencere disi sira numarasi: sunucu atar
            w.send(build(pkt, fake, -10000))
        STATS["fake"] += 1


def send_split(w, pkt, payload, pos, reverse):
    pos = max(1, min(pos, len(payload) - 1))
    p1 = build(pkt, payload[:pos], 0, clear_psh=True)
    p2 = build(pkt, payload[pos:], pos)
    for p in ((p2, p1) if reverse else (p1, p2)):
        w.send(p)


def process(w, pkt, a):
    if pkt.is_inbound:
        raw = bytes(pkt.raw)
        ihl = (raw[0] & 0x0F) * 4
        flags = raw[ihl + 13]
        if (flags & 0x12) == 0x12:      # SYN+ACK: sunucuya kac adim var?
            _hops[pkt.src_addr] = guess_hops(raw[8])
        elif (flags & 0x04) and a.rst_drop:  # RST: yalniz el sikismanin hemen ardindan
            key = (pkt.dst_addr, pkt.dst_port, pkt.src_addr, pkt.src_port)
            t = _flows.get(key)
            if t is not None and time.time() - t < RST_WINDOW:
                STATS["rst"] += 1
                return
        w.send(pkt)
        return

    if pkt.udp is not None:
        if pkt.udp.dst_port == 443:  # QUIC: engelle, tarayici TCP'ye dusurur
            if a.block_quic:
                STATS["quic"] += 1
                return
            w.send(pkt)
            return
        DNS_POOL.submit(handle_dns, w, pkt)  # DNS
        return

    if pkt.dst_addr in DOH_IPS:  # kendi DoH baglantimiz: dokunma
        w.send(pkt)
        return

    payload = bytes(pkt.tcp.payload)
    dport = pkt.tcp.dst_port

    if dport == 443 and payload[:2] == b"\x16\x03" and len(payload) > 2:
        now = time.time()
        _flows[(pkt.src_addr, pkt.src_port, pkt.dst_addr, pkt.dst_port)] = now
        if len(_flows) > 4000:
            for k in [k for k, v in _flows.items() if now - v > RST_WINDOW]:
                _flows.pop(k, None)
        STATS["hello"] += 1
        sni = find_sni(payload)
        pos = a.split or (sni[0] + sni[1] // 2 if sni else 2)
        fake = payload
        if sni:
            off, nl = sni
            f = bytearray(payload)
            f[off:off + nl] = (b"www.w3.org" * (nl // 10 + 1))[:nl]
            fake = bytes(f)
        send_fakes(w, pkt, fake, a)
        send_split(w, pkt, payload, pos, a.reverse)
        return

    if dport == 80 and payload.startswith(HTTP_METHODS):
        new = payload.replace(b"\r\nHost:", b"\r\nhOsT:", 1)  # ayni uzunluk
        send_split(w, pkt, new, a.split or 2, a.reverse)
        return

    w.send(pkt)


def run_windows(a):
    global DOH_URL
    DOH_URL = a.doh
    try:
        import pydivert
    except ImportError:
        sys.exit("pydivert yok. Kur:  pip install pydivert")
    if not ctypes.windll.shell32.IsUserAnAdmin():
        sys.exit("Yonetici olarak calistirmalisin (terminali 'Yonetici olarak ac').")
    flush_dns()
    print(f"Paket modu aktif. DNS-over-HTTPS: {'acik' if a.dns else 'kapali'}. "
          "Durdurmak icin Ctrl+C.")
    with pydivert.WinDivert(make_filter(a.dns, a.rst_drop, a.block_quic)) as w:
        for pkt in w:
            try:
                process(w, pkt, a)
            except Exception as e:
                print(f"[!] {e!r}")
                w.send(pkt)


# ----------------------------------------------------------------------------
# macOS / diger: proxy modu
# ----------------------------------------------------------------------------

DOH_URL = "https://1.1.1.1/dns-query"

DOH_ENDPOINTS = ["https://1.1.1.1/dns-query", "https://8.8.8.8/dns-query",
                 "https://9.9.9.9/dns-query", "https://1.0.0.1/dns-query",
                 "https://8.8.4.4/dns-query"]
DOH_POOL = ThreadPoolExecutor(max_workers=24)
_doh_cache = {}
_inflight = {}
_lock = threading.Lock()
_fail = {"n": 0, "until": 0.0}
_last_err = {"msg": ""}
_warned = {"doh": False}


def _ssl_context():
    """python.org'un macOS Python'unda CA deposu yoktur; certifi varsa onu kullan."""
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return None


def _make_opener():
    handlers = []
    if SYSTEM == "Darwin":
        # Sistem proxy'si bizim proxy'miz olacak: DoH istekleri ona takilmasin.
        handlers.append(urllib.request.ProxyHandler({}))
    ctx = _ssl_context()
    if ctx is not None:
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    return urllib.request.build_opener(*handlers)


_OPENER = _make_opener()


# --- DoH (RFC 8484, kablo formati): tum buyuk saglayicilarda ayni sekilde calisir
def dns_query_msg(host):
    q = b"".join(bytes([len(l)]) + l for l in host.encode("idna").split(b".")) + b"\x00"
    return struct.pack("!HHHHHH", 0, 0x0100, 1, 0, 0, 0) + q + struct.pack("!HH", 1, 1)


def _skip_name(msg, i):
    while True:
        ln = msg[i]
        if ln == 0:
            return i + 1
        if (ln & 0xC0) == 0xC0:
            return i + 2
        i += 1 + ln


def dns_answers(msg):
    """DNS yanitindaki IPv4 (A) adreslerini dondur (CNAME zincirini atlar)."""
    qd, an = struct.unpack_from("!HH", msg, 4)
    i = 12
    for _ in range(qd):
        i = _skip_name(msg, i) + 4
    ips = []
    for _ in range(an):
        i = _skip_name(msg, i)
        t, _c, _ttl, rl = struct.unpack_from("!HHIH", msg, i)
        i += 10
        if t == 1 and rl == 4:
            ips.append(socket.inet_ntoa(msg[i:i + 4]))
        i += rl
    return ips


def _doh_one(url, host):
    q = base64.urlsafe_b64encode(dns_query_msg(host)).rstrip(b"=").decode()
    req = urllib.request.Request(f"{url}?dns={q}",
                                 headers={"accept": "application/dns-message"})
    with _OPENER.open(req, timeout=3) as r:
        msg = r.read()
    return dns_answers(msg)


def doh_resolve(host):
    """Sunuculari paralel sorgula (ilk gecerli yanit kazanir).
    Donus: adres listesi, [] (kayit yok) ya da None (hicbirine ulasilamadi)."""
    urls = [DOH_URL] + [u for u in DOH_ENDPOINTS if u != DOH_URL]
    pending = {DOH_POOL.submit(_doh_one, u, host) for u in urls}
    result = None
    deadline = time.time() + 5
    while pending and time.time() < deadline:
        done, pending = wait(pending, timeout=max(0.05, deadline - time.time()),
                             return_when=FIRST_COMPLETED)
        for f in done:
            try:
                ips = f.result()
            except Exception as e:
                _last_err["msg"] = f"{type(e).__name__}: {e}"
                continue
            if ips:
                return ips
            result = []
    return result


def cached_doh(host):
    """Onbellekli ve ayni anda gelen ayni sorgulari birlestiren cozum.
    None = DoH'a ulasilamadi."""
    now = time.time()
    hit = _doh_cache.get(host)
    if hit and hit[1] > now:
        return hit[0]
    with _lock:
        fut = _inflight.get(host)
        owner = fut is None
        if owner:
            fut = _inflight[host] = Future()
    if not owner:
        try:
            return fut.result(timeout=7)
        except Exception:
            return None
    ips = None
    try:
        ips = doh_resolve(host)
        if ips:
            _doh_cache[host] = (ips, now + 300)
        elif ips is None:
            if not _warned["doh"]:
                _warned["doh"] = True
                print("[!] DoH sunucularına ulaşılamıyor "
                      f"({_last_err['msg'] or 'zaman aşımı'}). macOS'ta bu çoğunlukla "
                      "'certifi' paketi eksik olduğunda olur: run.command'ı yeniden "
                      "çalıştır.")
            if hit:
                ips = hit[0]  # eski kayit, hic yoktan iyidir
    finally:
        fut.set_result(ips)
        with _lock:
            _inflight.pop(host, None)
    return ips


def doh_query(host):
    ips = cached_doh(host)
    return ips[0] if ips else None


def doh_passthrough_allowed():
    """Art arda basarisizliktan sonra (DoH tamamen kapali) sistem DNS'ine izin ver."""
    now = time.time()
    _fail["n"] += 1
    if _fail["n"] >= 6:
        _fail["n"] = 0
        _fail["until"] = now + 30
    return now < _fail["until"]


# ----------------------------------------------------------------------------
# Kullanici alani (proxy) DPI atlatma yontemleri
#   cuts    : TCP parcalama noktalari (bayt ya da "start"/"mid"/"end" = SNI adi)
#   tlsrec  : ClientHello'yu IKI TLS KAYDINA bol (nokta, ornegin "mid")
#   disorder: ilk parcayi TTL=1 ile yolla (kaybolur), sonrakiler once ulasir
#   oob     : ilk parcadan sonra 1 bayt OOB (acil veri) ekle; sunucu atar, DPI gorur
# ----------------------------------------------------------------------------
def _st(**kw):
    base = dict(cuts=(), tlsrec=None, disorder=False, oob=False)
    base.update(kw)
    return base


PROXY_STRATEGIES = {
    "hafif":    _st(cuts=("mid",)),
    "dengeli":  _st(cuts=(1, "mid")),
    "guclu":    _st(cuts=(1, 5, "start", "mid")),
    "maksimum": _st(cuts=(1, 2, 5, "start", "mid", "end")),
    "tlsplus":  _st(cuts=(1, "mid"), tlsrec="mid"),
    "otomatik": _st(cuts=(1, "mid")),   # OTOMATIK BUL sonucuyla degisir
}

# Otomatik arama sirasi: hafiften agira
CANDIDATES = [
    ("SNI ortasından böl", _st(cuts=("mid",))),
    ("1. bayt + SNI ortası", _st(cuts=(1, "mid"))),
    ("TLS kaydını böl", _st(tlsrec="mid")),
    ("TLS kaydı + TCP böl", _st(cuts=(1, "mid"), tlsrec="mid")),
    ("Çoklu bölme", _st(cuts=(1, 5, "start", "mid"))),
    ("Sırasız (ilk parça TTL=1)", _st(cuts=("mid",), disorder=True)),
    ("TLS kaydı + sırasız", _st(cuts=("mid",), tlsrec="mid", disorder=True)),
    ("OOB baytı", _st(cuts=("mid",), oob=True)),
    ("TLS kaydı + OOB", _st(cuts=("mid",), tlsrec="mid", oob=True)),
    ("Maksimum bölme", _st(cuts=(1, 2, 5, "start", "mid", "end"))),
]

AUTO_PATH = os.path.join(os.path.expanduser("~"), ".projectsierra.json")
AUTO_PATH_OLD = os.path.join(os.path.expanduser("~"), ".projectzvezda.json")


def strategy_for(key):
    return PROXY_STRATEGIES.get(key) or PROXY_STRATEGIES["dengeli"]


def save_auto(st, name=""):
    PROXY_STRATEGIES["otomatik"] = st
    try:
        with open(AUTO_PATH, "w", encoding="utf-8") as f:
            json.dump({"name": name, "strategy": st}, f)
    except OSError:
        pass


def _load_auto():
    for path in (AUTO_PATH, AUTO_PATH_OLD):      # eski adli kayit da okunur
        try:
            with open(path, encoding="utf-8") as f:
                st = json.load(f)["strategy"]
            PROXY_STRATEGIES["otomatik"] = _st(
                cuts=tuple(st.get("cuts", ())), tlsrec=st.get("tlsrec"),
                disorder=bool(st.get("disorder")), oob=bool(st.get("oob")))
            return
        except Exception:
            continue


_load_auto()


def _pos(p, sni):
    if isinstance(p, int):
        return p
    if sni is None:
        return 2
    off, nl = sni
    return {"start": off, "mid": off + nl // 2, "end": off + nl}[p]


def tls_record_split(data, pos):
    """ClientHello'yu pos'tan iki TLS kaydina bol. Gecersizse None.
    Ikinci kaydin basligi (5 bayt) pos'a eklenir; sunucu el sikisma mesajini
    kayitlar arasinda birlestirir (RFC 8446 5.1), DPI ise genelde birlestirmez."""
    if len(data) < 16 or data[0] != 0x16:
        return None
    rec_len = struct.unpack_from("!H", data, 3)[0]
    if len(data) < 5 + rec_len:
        return None            # ClientHello eksik
    k = pos - 5                # ilk kayit govdesinin uzunlugu
    if not (8 <= k < rec_len):
        return None
    ver = data[1:3]
    body = data[5:5 + rec_len]
    rec1 = b"\x16" + ver + struct.pack("!H", k) + body[:k]
    rec2 = b"\x16" + ver + struct.pack("!H", rec_len - k) + body[k:]
    return rec1 + rec2 + data[5 + rec_len:]


def desync_steps(data, st):
    """Ilk TLS ucusunu adimlara cevir: [("data"|"oob", bayt, dusuk_ttl), ...]"""
    sni = find_sni(data)
    cuts = {_pos(p, sni) for p in st.get("cuts", ())}
    new = data
    if st.get("tlsrec"):
        tp = _pos(st["tlsrec"], sni)
        r = tls_record_split(data, tp)
        if r is not None:
            new = r
            cuts = {c if c <= tp else c + 5 for c in cuts}
            cuts.add(tp)       # iki kaydin arasindan da TCP'yi kes
            if not st.get("cuts"):
                cuts = {tp}
    bounds = [0] + sorted(c for c in cuts if 0 < c < len(new)) + [len(new)]
    segs = [new[bounds[i]:bounds[i + 1]] for i in range(len(bounds) - 1)]
    steps = []
    for i, seg in enumerate(segs):
        multi = len(segs) > 1
        steps.append(("data", seg, bool(st.get("disorder")) and i == 0 and multi))
        if st.get("oob") and i == 0 and multi:
            steps.append(("oob", b"\x00", False))
    return steps


def _ttl_opt(s):
    if s.family == socket.AF_INET6:
        return socket.IPPROTO_IPV6, socket.IPV6_UNICAST_HOPS
    return socket.IPPROTO_IP, socket.IP_TTL


def run_steps_sync(s, steps, delay):
    lvl, opt = _ttl_opt(s)
    ttl0 = s.getsockopt(lvl, opt)
    for kind, payload, low in steps:
        if kind == "oob":
            try:
                s.send(payload, socket.MSG_OOB)
            except OSError:
                pass
        else:
            if low:
                s.setsockopt(lvl, opt, 1)
            s.sendall(payload)
            if low:
                time.sleep(0.02)
                s.setsockopt(lvl, opt, ttl0)
        if len(steps) > 1:
            time.sleep(delay)


async def send_first_flight(loop, s, data, st, delay):
    steps = desync_steps(data, st)
    lvl, opt = _ttl_opt(s)
    ttl0 = s.getsockopt(lvl, opt)
    for kind, payload, low in steps:
        if kind == "oob":
            try:
                s.send(payload, socket.MSG_OOB)
            except OSError:
                pass
        else:
            if low:
                s.setsockopt(lvl, opt, 1)
            await loop.sock_sendall(s, payload)
            if low:
                await asyncio.sleep(0.02)
                s.setsockopt(lvl, opt, ttl0)
        if len(steps) > 1:
            await asyncio.sleep(delay)


# ----------------------------------------------------------------------------
# Tani ve otomatik yontem bulma
# ----------------------------------------------------------------------------
DIAG_HOSTS = ["discord.com", "www.roblox.com"]

_PROBE_TEXT = {
    "OK": "✔ açıldı (sertifika doğrulandı)",
    "CERT": "✘ SERTİFİKA GEÇERSİZ",
    "RESET": "✘ BAĞLANTI SIFIRLANDI (SNI engeli)",
    "TIMEOUT": "✘ ZAMAN AŞIMI",
}


def tls_probe(ip, host, st=None, port=443, ctx=None, timeout=6, delay=0.03):
    """ip:port'a host SNI'siyla DOGRULAMALI TLS dene -> (durum, ayrinti).
    st verilirse ilk ucus o yontemle (parcalama vb.) gonderilir."""
    ctx = ctx or _ssl_context() or ssl.create_default_context()
    inc, out = ssl.MemoryBIO(), ssl.MemoryBIO()
    obj = ctx.wrap_bio(inc, out, server_hostname=host)
    s = None
    try:
        s = socket.create_connection((ip, port), timeout=timeout)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        first = True
        while True:
            try:
                obj.do_handshake()
                tail = out.read()
                if tail:
                    s.sendall(tail)
                return "OK", obj.version()
            except ssl.SSLWantReadError:
                data = out.read()
                if data:
                    if first and st:
                        run_steps_sync(s, desync_steps(data, st), delay)
                    else:
                        s.sendall(data)
                    first = False
                chunk = s.recv(16384)
                if not chunk:
                    return "RESET", "sunucu bağlantıyı kapattı"
                inc.write(chunk)
    except ssl.SSLCertVerificationError as e:
        return "CERT", e.verify_message
    except ConnectionResetError:
        return "RESET", ""
    except (socket.timeout, TimeoutError):
        return "TIMEOUT", ""
    except ssl.SSLEOFError:
        return "RESET", "EOF"
    except (ssl.SSLError, OSError) as e:
        return "ERR", str(e)[:80]
    finally:
        if s is not None:
            s.close()


def _probe_text(res):
    st, det = res
    if st in _PROBE_TEXT:
        return _PROBE_TEXT[st] + (f" ({det})" if st == "CERT" and det else "")
    return f"✘ HATA ({det})"


def doh_selftest():
    """Her DoH sunucusunu ayri dene; sorun varsa asil hata mesajini goster."""
    ok = 0
    for u in DOH_ENDPOINTS:
        t0 = time.time()
        try:
            ips = _doh_one(u, "example.com")
            print(f"  DoH {urlparse(u).hostname}: ✔ ({int((time.time() - t0) * 1000)} ms)"
                  if ips else f"  DoH {urlparse(u).hostname}: boş yanıt")
            ok += bool(ips)
        except Exception as e:
            print(f"  DoH {urlparse(u).hostname}: ✘ {type(e).__name__}: {e}")
    return ok


def diagnose(hosts=None, strategy=None):
    """Sorunun nerede oldugunu gosterir: DNS mi, SNI engeli mi, IP yonlendirmesi mi."""
    if SYSTEM == "Darwin" and _ssl_context() is None:
        print("[!] 'certifi' kurulu değil: sertifika testleri yanıltıcı olur. "
              "run.command'ı yeniden çalıştır (paketleri kurar).")
        return {}
    print("=== Tanı başladı ===")
    if doh_selftest() == 0:
        print("DoH sunucularının HİÇBİRİNE ulaşılamıyor. Operatör DoH'u engelliyor "
              "ya da 'certifi' eksik (run.command'ı yeniden çalıştır).")
    verdict = {}
    for h in (hosts or DIAG_HOSTS):
        try:
            sys_ips = sorted({x[4][0] for x in
                              socket.getaddrinfo(h, 443, socket.AF_INET)})
        except OSError:
            sys_ips = []
        true_ips = doh_resolve(h) or []
        print(f"[{h}]")
        print(f"  sistem DNS   : {', '.join(sys_ips[:3]) or 'çözülemedi'}")
        print(f"  DoH (gerçek) : {', '.join(true_ips[:3]) or 'ulaşılamadı'}")
        if not true_ips:
            verdict[h] = "NODNS"
            continue
        ip = true_ips[0]
        plain = tls_probe(ip, h)
        print(f"  düz bağlantı      : {_probe_text(plain)}")
        verdict[h] = plain[0]
        if strategy is not None:
            res = tls_probe(ip, h, strategy)
            print(f"  seçili yöntemle   : {_probe_text(res)}")
            if res[0] == "OK":
                verdict[h] = "OK"
            elif plain[0] != "OK":
                verdict[h] = res[0]
    print("--- Yorum ---")
    states = set(verdict.values())
    if states == {"OK"}:
        print("Hepsi açılıyor. Tarayıcıyı tamamen kapatıp aç.")
    if "CERT" in states:
        print("SERTİFİKA GEÇERSİZ: doğru IP'ye gitmene rağmen operatör seni bir engel "
              "sayfasına yönlendiriyor (IP düzeyinde yönlendirme). Paket parçalama bunu "
              "AŞAMAZ; o site için tünel (VPN / Cloudflare WARP) gerekir.")
    if "RESET" in states:
        print("BAĞLANTI SIFIRLANDI: SNI engeli. 'OTOMATİK BUL' ile çalışan yöntemi ara.")
    if "TIMEOUT" in states or "NODNS" in states:
        print("ZAMAN AŞIMI / DNS YOK: IP engellenmiş olabilir ya da DoH'a ulaşılamıyor.")
    if SYSTEM == "Darwin":
        check_app_dns()
    print("=== Tanı bitti ===")
    return verdict


def autotune(hosts=None, resolver=None, port=443, ctx=None, candidates=None,
             delay=0.03, save=True):
    """Gercek operatorunde hangi yontemin calistigini dener ve 'Otomatik' profilini
    ayarlar. Doner: (ad, strateji) ya da None."""
    hosts = hosts or DIAG_HOSTS
    resolver = resolver or doh_resolve
    cands = candidates or CANDIDATES
    if SYSTEM == "Darwin" and ctx is None and _ssl_context() is None:
        print("[!] 'certifi' kurulu değil: sertifika testleri yanıltıcı olur. "
              "run.command'ı yeniden çalıştır (paketleri kurar).")
        return None
    print("=== Otomatik yöntem arama ===")
    ips = {}
    for h in hosts:
        r = resolver(h)
        if not r:
            print(f"[{h}] DoH ile çözülemedi; arama durduruldu. Önce TANI'yı çalıştır.")
            return None
        ips[h] = r[0]

    def probe_all(st):
        res = {}
        ths = []

        def one(h):
            res[h] = tls_probe(ips[h], h, st, port=port, ctx=ctx, delay=delay)
        for h in hosts:
            t = threading.Thread(target=one, args=(h,), daemon=True)
            t.start()
            ths.append(t)
        for t in ths:
            t.join()
        return res

    base = probe_all(None)
    for h in hosts:
        print(f"  müdahalesiz  {h}: {_probe_text(base[h])}")
    if all(base[h][0] == "OK" for h in hosts):
        print("Müdahale gerekmiyor: hepsi zaten açılıyor.")
        print("=== Arama bitti ===")
        return None

    best = None  # (puan, ad, strateji)
    for name, st in cands:
        res = probe_all(st)
        marks = "  ".join(f"{h.split('.')[-2] if h.count('.') else h}:"
                          f"{'✔' if res[h][0] == 'OK' else '✘'}" for h in hosts)
        print(f"  {name:<28} {marks}")
        score = sum((2 if "roblox" in h else 1) for h in hosts if res[h][0] == "OK")
        if best is None or score > best[0]:
            best = (score, name, st, res)
        if all(res[h][0] == "OK" for h in hosts):
            break
    score, name, st, res = best
    base_score = sum((2 if "roblox" in h else 1) for h in hosts
                     if base[h][0] == "OK")
    if score <= base_score:
        print("Hiçbir yöntem sonucu iyileştirmedi.")
        for h in hosts:
            if res[h][0] == "CERT":
                print(f"  {h}: sertifika geçersiz → IP düzeyinde yönlendirme; "
                      "parçalama işe yaramaz, tünel (VPN/WARP) gerekir.")
            elif res[h][0] == "RESET":
                print(f"  {h}: bağlantı sıfırlanıyor → bu yöntemler (kullanıcı alanı) "
                      "yetmiyor; sahte paket gerekir (Windows'ta paket modu / zapret).")
        print("=== Arama bitti ===")
        return None
    for h in hosts:
        print(f"  seçilen yöntemle {h}: {_probe_text(res[h])}")
    if save:
        save_auto(st, name)
    print(f"Seçildi: {name}. 'Otomatik' profili kaydedildi; BAŞLAT ile kullan.")
    print("=== Arama bitti ===")
    return name, st


# ----------------------------------------------------------------------------
# Proxy
# ----------------------------------------------------------------------------
async def resolve_all(host, use_doh=True):
    """Alan adini adres listesine cevir. DoH ulasilamazsa sistem (zehirli olabilir)
    DNS'ine DUSMEZ: hata verir, tarayici tekrar dener."""
    try:
        ipaddress.ip_address(host)
        return [host]
    except ValueError:
        pass
    loop = asyncio.get_running_loop()
    if use_doh:
        ips = await loop.run_in_executor(None, cached_doh, host)
        if ips:
            STATS["dns"] += 1
            return ips
        if ips is None and not doh_passthrough_allowed():
            raise OSError(f"DoH ile çözülemedi: {host}")
        if ips == []:
            raise OSError(f"DNS kaydı yok: {host}")
    info = await loop.getaddrinfo(host, None, family=socket.AF_INET)
    return list(dict.fromkeys(x[4][0] for x in info))


async def connect_any(ips, port):
    """Adresleri sirayla dene; baglanmis, bloklamayan soketi dondur."""
    loop = asyncio.get_running_loop()
    last = None
    for ip in ips[:4]:
        fam = socket.AF_INET6 if ":" in ip else socket.AF_INET
        s = socket.socket(fam, socket.SOCK_STREAM)
        s.setblocking(False)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        try:
            await asyncio.wait_for(loop.sock_connect(s, (ip, port)), 6)
            return s
        except Exception as e:
            last = e
            s.close()
    raise last or OSError("bağlantı kurulamadı")


async def read_client_hello(cr):
    """Istemcinin ilk verisi; TLS ise kaydin tamami gelene kadar oku."""
    first = await asyncio.wait_for(cr.read(65536), 15)
    if first and first[0] == 0x16 and len(first) >= 5:
        need = 5 + struct.unpack_from("!H", first, 3)[0]
        while len(first) < need and need <= 20000:
            more = await asyncio.wait_for(cr.read(need - len(first)), 5)
            if not more:
                break
            first += more
    return first


def fmt_hms(secs):
    t = int(max(0, secs))
    return f"{t // 3600:02d}:{t // 60 % 60:02d}:{t % 60:02d}"


_UNITS = ("B", "KB", "MB", "GB", "TB")


def fmt_bytes(n, digits=None):
    """1024 tabanli: 0 B, 12.3 KB, 412.7 MB, 1.84 GB. digits=None -> birime gore."""
    n = max(0.0, float(n))
    i = 0
    while n >= 1024 and i < len(_UNITS) - 1:
        n /= 1024
        i += 1
    if i == 0:
        return f"{int(n)} B"
    dg = digits if digits is not None else (1 if i < 3 else 2)
    if round(n, dg) >= 1024 and i < len(_UNITS) - 1:      # 1023.96 KB -> 1.0 MB
        n /= 1024
        i += 1
        dg = digits if digits is not None else (1 if i < 3 else 2)
    return f"{n:.{dg}f} {_UNITS[i]}"


_MB, _GB = 1024 ** 2, 1024 ** 3
_LIMITS = [100 * _MB, 250 * _MB, 500 * _MB, _GB, 2 * _GB, 5 * _GB, 10 * _GB,
           20 * _GB, 50 * _GB, 100 * _GB, 250 * _GB, 500 * _GB, 1024 * _GB]


def pick_limit(total):
    """Cubugun doluluk olcegi: toplamin altindaki ilk yuvarlak esik."""
    for lim in _LIMITS:
        if total < lim:
            return lim
    tb = 1024 * _GB
    return (int(total // tb) + 1) * tb


_VIRT_WIN = ("loopback", "vethernet", "isatap", "teredo", "vmware", "virtualbox", "pseudo")
_VIRT_UNIX = ("lo0", "utun", "awdl", "llw", "bridge", "ap1", "gif", "stf",
              "anpi", "vmenet", "vboxnet", "docker", "veth", "virbr")


def _read_net_counters():
    """(indirilen, yuklenen) bayt toplami; yalniz fiziksel arayuzler. psutil yoksa None."""
    try:
        import psutil
    except ImportError:
        return None
    try:
        rx = tx = 0
        for name, c in psutil.net_io_counters(pernic=True).items():
            low = name.lower()
            if SYSTEM == "Windows":
                if any(k in low for k in _VIRT_WIN):
                    continue
            elif low == "lo" or low.startswith(_VIRT_UNIX):
                continue
            rx += c.bytes_recv
            tx += c.bytes_sent
        return rx, tx
    except Exception:
        return None


class NetMeter:
    """Oturum boyunca kullanilan internet (indirilen/yuklenen) ve anlik hiz.

    Kaynak: psutil varsa tum fiziksel arayuzlerin sayaclari ("sistem"); yoksa
    yalnizca bu uygulamanin proxy/role uzerinden gecirdigi baytlar ("uygulama").
    """

    def __init__(self, reader=None, clock=None):
        self._reader = reader or _read_net_counters
        self._clock = clock or time.time
        self.source = "sistem"
        self.reset()

    def _read(self):
        r = self._reader()
        if r is not None:
            self.source = "sistem"
            return r
        self.source = "uygulama"
        return STATS.get("down", 0), STATS.get("up", 0)

    def reset(self):
        self._base = self._prev = self._read()
        self._t = self._clock()
        self._rate = 0.0
        self.last = {"down": 0, "up": 0, "total": 0, "rate": 0.0}

    def sample(self):
        now = self._clock()
        cur = self._read()
        if cur[0] < self._prev[0] or cur[1] < self._prev[1]:
            # sayac sifirlandi (arayuz kapandi/acildi): birikmis kullanimi koru
            acc = (self._prev[0] - self._base[0], self._prev[1] - self._base[1])
            self._base = (cur[0] - acc[0], cur[1] - acc[1])
            self._prev = cur
        dt = now - self._t
        if dt >= 0.5:
            inst = ((cur[0] - self._prev[0]) + (cur[1] - self._prev[1])) / dt
            self._rate = inst if self._rate == 0.0 else 0.5 * self._rate + 0.5 * inst
            self._prev, self._t = cur, now
        down, up = cur[0] - self._base[0], cur[1] - self._base[1]
        self.last = {"down": down, "up": up, "total": down + up, "rate": self._rate}
        return self.last


async def pipe(r, w, key=None):
    try:
        while True:
            chunk = await r.read(65536)
            if not chunk:
                break
            if key:
                STATS[key] += len(chunk)
            w.write(chunk)
            await w.drain()
    except Exception:
        pass
    finally:
        try:
            w.close()
        except Exception:
            pass


async def handle(cr, cw, a):
    s = rw = None
    try:
        head = await asyncio.wait_for(cr.readuntil(b"\r\n\r\n"), 15)
        method, target, _ = head.split(b"\r\n")[0].decode().split(" ", 2)
        if method != "CONNECT":
            cw.write(b"HTTP/1.1 405 Method Not Allowed\r\n\r\n")
            await cw.drain()
            return
        host, _, port = target.rpartition(":")
        host = host.strip("[]")
        STATS["conn"] += 1
        loop = asyncio.get_running_loop()
        try:
            ips = await resolve_all(host, getattr(a, "dns", True))
            s = await connect_any(ips, int(port))
        except Exception as e:
            cw.write(b"HTTP/1.1 502 Bad Gateway\r\n\r\n")
            await cw.drain()
            STATS["err"] += 1
            print(f"[!] {host}: {e}")
            return
        cw.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
        await cw.drain()
        first = await read_client_hello(cr)
        if not first:
            return
        if first[0] == 0x16:
            STATS["hello"] += 1
            await send_first_flight(loop, s, first, a.strategy, a.delay)
        else:
            await loop.sock_sendall(s, first)
        STATS["up"] += len(first)           # ilk paket pipe() disinda gider
        rr, rw = await asyncio.open_connection(sock=s)
        s = None  # artik rw sahip
        await asyncio.gather(pipe(cr, rw, "up"), pipe(rr, cw, "down"))
    except Exception as e:
        STATS["err"] += 1
        print(f"[!] {e!r}")
    finally:
        for x in (cw, rw):
            try:
                if x:
                    x.close()
            except Exception:
                pass
        if s is not None:
            s.close()


# ----------------------------------------------------------------------------
# macOS: UYGULAMA DESTEGI (sistem proxy'sini kullanmayan uygulamalar, ornegin
# Roblox Player). /etc/resolver/<alan> ile su alan adlarinin DNS sorgulari yerel
# bir DNS yonlendiricisine (127.0.0.1:5300) gider:
#   RELAY alanlari (Roblox): A sorgusuna 127.0.0.1 doner. Uygulama yerel role'ye
#     (0.0.0.0:443, yalniz bu bilgisayardan) baglanir; role SNI'yi okur, GERCEK
#     IP'yi DoH ile bulur ve ClientHello'yu parcalayarak sunucuya gider. Sertifika
#     dogrulamasini uygulama gercek sunucuyla yapar (role TLS'i acmaz).
#   DIGER alanlar (Discord): DoH ile dogru (zehirsiz) yanit.
# ----------------------------------------------------------------------------
APP_RELAY_DOMAINS = ("roblox.com", "rbxcdn.com", "rbxtrk.com", "robloxlabs.com")
APP_TRUTH_DOMAINS = ("discord.com", "discord.gg", "discordapp.com",
                     "discordapp.net", "discord.media", "discordcdn.com",
                     "discordstatus.com", "discord.gift", "discord.new",
                     "discordsays.com")
APP_DNS_DOMAINS = APP_RELAY_DOMAINS + APP_TRUTH_DOMAINS
APP_DNS_PORT = 5300          # yerel DNS yonlendirici (443'ten farkli: root gerekmez)
APP_RELAY_PORT = 443         # macOS 10.14+: joker adrese (0.0.0.0) root'suz baglanilir
APP_UPSTREAM_PORT = 443
RELAY_BLOCK_LOOPBACK = True  # role, kendi kendine baglanmasin (dongu korumasi)
RESOLVER_DIR = "/etc/resolver"
RESOLVER_MARK = "# Project SieRra"
RESOLVER_MARK_OLD = "# Project Zvezda"      # onceki surumden kalan dosyalari da tanir
DNS_FLUSH = "/usr/bin/dscacheutil -flushcache; /usr/bin/killall -HUP mDNSResponder"
APP_DNS_HOSTS = ["clientsettingscdn.roblox.com", "apis.roblox.com",
                 "auth.roblox.com"]


def in_domains(host, domains):
    host = host.lower().rstrip(".")
    return any(host == d or host.endswith("." + d) for d in domains)


def dns_question(raw):
    """(ad, tur, soru_sonu) ya da None. Yalniz standart, tek sorulu sorgular."""
    try:
        if len(raw) < 17 or (raw[2] & 0x80) or (raw[2] & 0x78):
            return None
        if struct.unpack_from("!H", raw, 4)[0] != 1:
            return None
        i, labels = 12, []
        while True:
            ln = raw[i]
            if ln == 0:
                i += 1
                break
            if ln & 0xC0:
                return None
            labels.append(raw[i + 1:i + 1 + ln].decode("ascii"))
            i += 1 + ln
        if i + 4 > len(raw):
            return None
        return ".".join(labels).lower(), struct.unpack_from("!H", raw, i)[0], i + 4
    except Exception:
        return None


def dns_reply(raw, qend, answers=b"", count=0, rcode=0):
    flags = 0x8180 | rcode                         # yanit + RD + RA
    return (raw[:2] + struct.pack("!HHHHH", flags, 1, count, 0, 0)
            + raw[12:qend] + answers)


def dns_a_answer(ip, ttl=30):
    return b"\xc0\x0c" + struct.pack("!HHIH", 1, 1, ttl, 4) + socket.inet_aton(ip)


_fwd_cache = {}


def _doh_wire(url, q0):
    qb = base64.urlsafe_b64encode(q0).rstrip(b"=").decode()
    req = urllib.request.Request(f"{url}?dns={qb}",
                                 headers={"accept": "application/dns-message"})
    with _OPENER.open(req, timeout=3) as r:
        return r.read()


def doh_forward(raw):
    """Ham DNS sorgusunu DoH ile coz; ham yaniti (ayni ID ile) dondur. None = ulasilamadi."""
    if len(raw) < 17:
        return None
    qid, q0 = raw[:2], b"\x00\x00" + raw[2:]     # ID=0: RFC 8484 onbellek uyumu
    now = time.time()
    hit = _fwd_cache.get(q0)
    if hit and hit[1] > now:
        return qid + hit[0][2:]
    urls = [DOH_URL] + [u for u in DOH_ENDPOINTS if u != DOH_URL]
    pending = {DOH_POOL.submit(_doh_wire, u, q0) for u in urls}
    deadline = now + 5
    while pending and time.time() < deadline:
        done, pending = wait(pending, timeout=max(0.05, deadline - time.time()),
                             return_when=FIRST_COMPLETED)
        for f in done:
            try:
                msg = f.result()
            except Exception as e:
                _last_err["msg"] = f"{type(e).__name__}: {e}"
                continue
            if len(msg) >= 12 and (msg[2] & 0x80):
                if len(_fwd_cache) > 2000:
                    _fwd_cache.clear()
                _fwd_cache[q0] = (msg, time.time() + 30)
                return qid + msg[2:]
    return qid + hit[0][2:] if hit else None


class AppDnsProtocol(asyncio.DatagramProtocol):
    def __init__(self, svc):
        self.svc = svc
        self.t = None

    def connection_made(self, transport):
        self.t = transport

    def datagram_received(self, data, addr):
        asyncio.ensure_future(self._answer(data, addr))

    async def _answer(self, data, addr):
        try:
            q = dns_question(data)
            if q is None:
                return
            name, qtype, qend = q
            if qtype in (28, 64, 65):          # AAAA/SVCB/HTTPS: bos yanit -> IPv4'e dus
                resp = dns_reply(data, qend)
            elif (qtype == 1 and self.svc.relay_up
                  and in_domains(name, APP_RELAY_DOMAINS)):
                resp = dns_reply(data, qend, dns_a_answer("127.0.0.1"), 1)
                STATS["dns"] += 1
            else:
                loop = asyncio.get_running_loop()
                resp = await loop.run_in_executor(None, doh_forward, data)
                if resp is None:
                    resp = dns_reply(data, qend, rcode=2)        # SERVFAIL
                else:
                    STATS["dns"] += 1
            self.t.sendto(resp, addr)
        except Exception as e:
            print(f"[!] DNS: {e!r}")


async def app_relay_handle(cr, cw, a):
    """Roblox gibi uygulamalardan gelen (127.0.0.1:443) TLS baglantisini gercek
    sunucuya parcalayarak aktar. SNI'ye gore gercek IP DoH ile bulunur."""
    s = rw = None
    try:
        peer = cw.get_extra_info("peername")
        if not peer or not str(peer[0]).startswith("127."):
            return                                   # yalniz bu bilgisayardan
        first = await read_client_hello(cr)
        if not first or first[0] != 0x16:
            return
        sni = find_sni(first)
        if not sni:
            return
        host = first[sni[0]:sni[0] + sni[1]].decode("ascii", "ignore").lower().rstrip(".")
        if not in_domains(host, APP_RELAY_DOMAINS):
            print(f"[!] röle: izin verilmeyen ad reddedildi: {host}")
            return
        STATS["conn"] += 1
        loop = asyncio.get_running_loop()
        ips = await loop.run_in_executor(None, cached_doh, host)
        if RELAY_BLOCK_LOOPBACK:
            ips = [ip for ip in (ips or []) if not ip.startswith("127.")]
        if not ips:
            raise OSError(f"DoH ile çözülemedi: {host}")
        STATS["dns"] += 1
        s = await connect_any(ips, APP_UPSTREAM_PORT)
        STATS["hello"] += 1
        await send_first_flight(loop, s, first, a.strategy, a.delay)
        STATS["up"] += len(first)
        rr, rw = await asyncio.open_connection(sock=s)
        s = None
        await asyncio.gather(pipe(cr, rw, "up"), pipe(rr, cw, "down"))
    except Exception as e:
        STATS["err"] += 1
        print(f"[!] röle: {e!r}")
    finally:
        for x in (cw, rw):
            try:
                if x:
                    x.close()
            except Exception:
                pass
        if s is not None:
            s.close()


class AppDnsService:
    """Yerel DNS yonlendirici (UDP) + Roblox rolesi (TCP :443)."""

    def __init__(self):
        self.transport = None
        self.port = None
        self.relay = None
        self.relay_up = False

    async def start(self, a):
        loop = asyncio.get_running_loop()
        try:
            self.relay = await asyncio.start_server(
                lambda r, w: app_relay_handle(r, w, a), "0.0.0.0", APP_RELAY_PORT)
            self.relay_up = True
        except OSError as e:
            print(f"Yerel röle (:{APP_RELAY_PORT}) açılamadı ({e.strerror or e}). "
                  "DNS yalnızca doğru IP'leri verecek; parçalama uygulanamaz.")
        for p in range(APP_DNS_PORT, APP_DNS_PORT + 20):
            try:
                self.transport, _ = await loop.create_datagram_endpoint(
                    lambda: AppDnsProtocol(self), local_addr=("127.0.0.1", p))
                self.port = p
                break
            except OSError:
                continue
        if self.transport is None:
            print("Uygulama DNS yönlendiricisi başlatılamadı.")
            self.close()
            return False
        print(f"Uygulama desteği hazır: DNS 127.0.0.1:{self.port}"
              + (f", röle :{APP_RELAY_PORT}" if self.relay_up else ""))
        return True

    def close(self):
        if self.transport is not None:
            self.transport.close()
            self.transport = None
        if self.relay is not None:
            self.relay.close()
            self.relay = None
        self.relay_up = False


def check_app_dns(hosts=None, port=443, ctx=None, sys_resolve=None):
    """Sistem proxy'sini KULLANMAYAN uygulamalarin (Roblox Player) yolunu dener:
    sistemin verdigi IP + duz TLS (dogrulamali)."""
    print("--- Uygulama yolu (proxy'siz): sistem DNS + düz TLS ---")
    states = []
    for h in (hosts or APP_DNS_HOSTS):
        if sys_resolve is not None:
            sys_ips = sys_resolve(h)
        else:
            try:
                sys_ips = sorted({x[4][0] for x in
                                  socket.getaddrinfo(h, 443, socket.AF_INET)})
            except OSError:
                sys_ips = []
        if not sys_ips:
            print(f"  {h}: sistem DNS çözemedi")
            states.append("NODNS")
            continue
        ip = sys_ips[0]
        res = tls_probe(ip, h, port=port, ctx=ctx)
        states.append(res[0])
        tag = " (yerel röle)" if ip.startswith("127.") else ""
        print(f"  {h}: {ip}{tag} → {_probe_text(res)}")
    st = set(states)
    if st == {"OK"}:
        print("✔ Uygulamalar için yol açık.")
    if "CERT" in st:
        print("✘ SERTİFİKA GEÇERSİZ: sistem DNS'i seni engel sayfasına götürüyor "
              "(Roblox uygulamasındaki 'TlsVerificationFail' budur). BAŞLAT'tan önce "
              "'Uygulama desteği' anahtarını aç; yönetici parolasını gir.")
    if "RESET" in st:
        print("✘ BAĞLANTI SIFIRLANDI: DNS doğru ama SNI engeli var. Uygulama desteği "
              "açıksa röle (443) çalışıyor mu? Günlükte 'röle' satırlarına bak.")
    if st & {"TIMEOUT", "NODNS"}:
        print("✘ Zaman aşımı / DNS yok: yerel DNS yönlendirici çalışmıyor ya da IP engelli.")
    return states


NETWORKSETUP = "/usr/sbin/networksetup"
_mac = {"cur": None}


def mac_services():
    out = subprocess.run([NETWORKSETUP, "-listallnetworkservices"],
                         capture_output=True, text=True).stdout
    return [l.strip() for l in out.splitlines()[1:]
            if l.strip() and not l.startswith("*")]


def _mac_script(services, host, port, stop, pid, dns=None):
    """Tek bir yonetici oturumunda calisacak sh betigi.

    Sistem proxy'sini ve/veya uygulama DNS yonlendirmesini (/etc/resolver) acar,
    sonra arka planda bir bekci birakir: `stop` dosyasi olusunca YA DA uygulama
    (pid) olunce hepsini geri alir. Boylece uygulama cokse bile sistem ayarlari
    olu bir porta bakar halde kalmaz ve kapatirken ikinci bir parola istenmez.
    dns = (alan_adlari, yerel_dns_portu) ya da None.
    """
    q = shlex.quote
    on = "".join(
        f"{NETWORKSETUP} -setsecurewebproxy {q(s)} {q(host)} {int(port)}; "
        f"{NETWORKSETUP} -setsecurewebproxystate {q(s)} on; " for s in services)
    off = "".join(f"{NETWORKSETUP} -setsecurewebproxystate {q(s)} off; "
                  for s in services)
    if dns:
        domains, dport = dns
        body = f"{RESOLVER_MARK}\\nnameserver 127.0.0.1\\nport {int(dport)}\\n"
        on += f'MINE=""; mkdir -p {q(RESOLVER_DIR)}; '
        for dom in domains:
            f = f"{RESOLVER_DIR}/{dom}"
            # Kullanicinin kendi dosyasini ezme: yalniz yoksa ya da bizimse yaz.
            on += (f"if [ ! -e {q(f)} ] || grep -q -e {q(RESOLVER_MARK)} -e {q(RESOLVER_MARK_OLD)} {q(f)} "
                   f"2>/dev/null; then printf {q(body)} > {q(f)} && "
                   f'MINE="$MINE {q(f)}"; fi; ')
        on += f"{DNS_FLUSH}; "
        off += f'for f in $MINE; do rm -f "$f"; done; {DNS_FLUSH}; '
    return (f"if [ ! -e {q(stop)} ]; then {on}"
            f"( while kill -0 {int(pid)} 2>/dev/null && [ ! -e {q(stop)} ]; "
            f"do sleep 1; done; {off}rm -f {q(stop)} ) >/dev/null 2>&1 & fi")


def _admin_popen(script):
    """Betigi yonetici yetkisiyle baslat (root degilsek tek parola penceresi)."""
    if os.geteuid() == 0:
        cmd = ["/bin/sh", "-c", script]
    else:
        lit = script.replace("\\", "\\\\").replace('"', '\\"')
        cmd = ["/usr/bin/osascript", "-e",
               f'do shell script "{lit}" with administrator privileges']
    return subprocess.Popen(cmd, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True)


def mac_system_on(host, port, use_proxy=True, dns_port=None):
    """Tek yonetici parolasiyla sistem HTTPS proxy'sini ve/veya uygulama DNS
    yonlendirmesini ac. True = acildi."""
    if SYSTEM != "Darwin":
        return False
    services = mac_services() if use_proxy else []
    if use_proxy and not services:
        print("Etkin ağ servisi bulunamadı; sistem proxy'si açılmadı.")
        use_proxy = False
    if not use_proxy and not dns_port:
        return False
    dns = (APP_DNS_DOMAINS, dns_port) if dns_port else None
    what = " + ".join(w for w in ("sistem proxy'si" if services else "",
                                  "uygulama DNS'i" if dns else "") if w)
    tmp = tempfile.mkdtemp(prefix="sierra-")
    cur = {"dir": tmp, "stop": os.path.join(tmp, "stop"), "proc": None,
           "on": False, "cancel": False}
    _mac["cur"] = cur
    print(f"Yönetici parolası istenecek ({what})...")
    proc = _admin_popen(_mac_script(services, host, port, cur["stop"],
                                    os.getpid(), dns))
    cur["proc"] = proc
    try:
        _, err = proc.communicate(timeout=180)
    except subprocess.TimeoutExpired:
        proc.kill()
        print("Parola penceresi zaman aşımına uğradı; sistem ayarları açılmadı.")
        return False
    if cur["cancel"]:
        return False
    if proc.returncode != 0:
        print("Sistem ayarları açılmadı (yönetici izni verilmedi). Proxy "
              f"{host}:{port} adresinde yine çalışıyor; tarayıcıda elle "
              "ayarlayabilirsin.")
        return False
    cur["on"] = True
    if services:
        print("macOS sistem HTTPS proxy'si açıldı.")
    if dns:
        print("Uygulama DNS yönlendirmesi açıldı "
              f"({len(APP_RELAY_DOMAINS)} Roblox + {len(APP_TRUTH_DOMAINS)} Discord alanı).")
    return True


def mac_proxy_on(host, port):
    return mac_system_on(host, port, True, None)


def mac_dns_cleanup():
    """Artik /etc/resolver kayitlarini (yalniz bizim isaretli olanlari) sil."""
    q = shlex.quote
    cmds = "".join(
        f"if grep -q -e {q(RESOLVER_MARK)} -e {q(RESOLVER_MARK_OLD)} {q(f'{RESOLVER_DIR}/{d}')} 2>/dev/null; "
        f"then rm -f {q(f'{RESOLVER_DIR}/{d}')}; fi; " for d in APP_DNS_DOMAINS)
    p = _admin_popen(cmds + DNS_FLUSH)
    p.communicate(timeout=180)
    print("Temizlendi." if p.returncode == 0 else "Temizlenemedi (izin verilmedi).")
    return p.returncode == 0


def mac_proxy_off():
    """Sistem proxy'sini kapat (parola istemez; bekci surec kapatir)."""
    cur = _mac.get("cur")
    if not cur:
        return
    _mac["cur"] = None
    cur["cancel"] = True
    proc = cur["proc"]
    pending = proc is not None and proc.poll() is None
    try:
        open(cur["stop"], "w").close()
    except OSError:
        pass
    if pending:
        # Parola penceresi hala acik: betik calismis olabilir, stop dosyasini
        # birakiyoruz (betik gorurse hicbir sey acmaz / hemen kapatir).
        proc.terminate()
        return
    if cur["on"]:
        deadline = time.time() + 10
        while os.path.exists(cur["stop"]) and time.time() < deadline:
            time.sleep(0.2)
        if os.path.exists(cur["stop"]):
            print("Uyarı: sistem proxy'sinin kapandığı doğrulanamadı. Gerekirse "
                  "Sistem Tercihleri > Ağ > Gelişmiş > Proxy'ler'den kapat.")
            return
        print("macOS sistem proxy'si kapatıldı.")
    shutil.rmtree(cur["dir"], ignore_errors=True)


async def proxy_main(a):
    global DOH_URL
    DOH_URL = a.doh
    server = await asyncio.start_server(lambda r, w: handle(r, w, a),
                                        a.host, a.port)
    print(f"Proxy modu: {a.host}:{a.port}  (durdurmak icin Ctrl+C)")
    svc = AppDnsService() if (SYSTEM == "Darwin" and a.app_dns) else None
    try:
        async with server:
            if svc is not None and not await svc.start(a):
                svc = None
            use_proxy = bool(a.system_proxy and SYSTEM == "Darwin")
            if use_proxy or svc is not None:
                # Port baglandiktan sonra ac: baslatma basarisizsa parola sorulmaz.
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(None, mac_system_on, a.host, a.port,
                                           use_proxy, svc.port if svc else None)
            await server.serve_forever()
    finally:
        if svc is not None:
            svc.close()


def run_proxy(a):
    use_sys = (a.system_proxy or a.app_dns) and SYSTEM == "Darwin"
    try:
        asyncio.run(proxy_main(a))
    except KeyboardInterrupt:
        pass
    finally:
        if use_sys:
            mac_proxy_off()


# ----------------------------------------------------------------------------


def main():
    ap = argparse.ArgumentParser(description="Project : SieRra - DPI atlatma araci")
    ap.add_argument("--mode", choices=["auto", "packet", "proxy"], default="auto")
    ap.add_argument("--profile", default="dengeli",
                    choices=sorted(set(PROFILES) | set(PROXY_STRATEGIES)),
                    help="guc seviyesi (calismazsa sirayla yukari cik); "
                         "tlsplus/otomatik yalniz proxy modunda (macOS)")
    ap.add_argument("--diagnose", action="store_true",
                    help="DNS / SNI / IP yonlendirme tanisi yap ve cik")
    ap.add_argument("--autotune", action="store_true",
                    help="[macOS/proxy] calisan yontemi otomatik ara ve kaydet")
    ap.add_argument("--split", type=int, default=None,
                    help="ClientHello bolme noktasi (0 = SNI ortasi)")
    ap.add_argument("--fake-ttl", type=int, default=None,
                    help="[Windows] TTL'li sahte paket (0 = kapat)")
    ap.add_argument("--reverse", action="store_const", const=True, default=None,
                    help="[Windows] parcalari ters sirada gonder")
    ap.add_argument("--no-dns", action="store_true",
                    help="[Windows] DNS'i DoH ile cozmeyi kapat")
    ap.add_argument("--no-rst", action="store_true",
                    help="[Windows] sahte RST bastirmayi kapat")
    ap.add_argument("--no-quic", action="store_true",
                    help="[Windows] QUIC'i (UDP/443) engelleme")
    ap.add_argument("--host", default="127.0.0.1", help="[proxy] adres")
    ap.add_argument("--port", type=int, default=8080, help="[proxy] port")
    ap.add_argument("--doh", default=DOH_URL, help="DoH sunucusu")
    ap.add_argument("--delay", type=float, default=0.05,
                    help="[proxy] parcalar arasi bekleme (sn)")
    ap.add_argument("--system-proxy", action="store_true",
                    help="[macOS] sistem proxy'sini otomatik ac/kapat")
    ap.add_argument("--app-dns", action="store_true",
                    help="[macOS] proxy'yi kullanmayan uygulamalar (Roblox Player) "
                         "icin DNS yonlendirmesi + yerel role")
    ap.add_argument("--cleanup-dns", action="store_true",
                    help="[macOS] artik /etc/resolver kayitlarini sil ve cik")
    c = ap.parse_args()

    over = dict(dns=not c.no_dns, rst_drop=not c.no_rst,
                block_quic=not c.no_quic, host=c.host, port=c.port,
                doh=c.doh, delay=c.delay, system_proxy=c.system_proxy,
                app_dns=c.app_dns)
    if c.split is not None:
        over["split"] = c.split
    if c.reverse:
        over["reverse"] = True
    if c.cleanup_dns:
        mac_dns_cleanup()
        return
    if c.diagnose:
        diagnose(strategy=None if SYSTEM == "Windows" else strategy_for(c.profile))
        return
    if c.autotune:
        autotune()
        return
    a = make_args(c.profile, **over)
    if c.split is not None:
        a.strategy = dict(a.strategy, cuts=(1, c.split or "mid"))
    if c.fake_ttl is not None:
        fk = [f for f in a.fakes if f != "ttl"]
        if c.fake_ttl > 0:
            fk.append("ttl")
            a.fake_ttl = c.fake_ttl
        a.fakes = tuple(fk)

    mode = c.mode
    if mode == "auto":
        mode = "packet" if SYSTEM == "Windows" else "proxy"
    if mode == "packet":
        if SYSTEM != "Windows":
            sys.exit("Paket modu sadece Windows'ta var. --mode proxy kullan.")
        run_windows(a)
    else:
        run_proxy(a)


if __name__ == "__main__":
    main()
