# Project : SieRra — macOS (12.7.6 ve üzeri)

## Arayüz (Windows ve macOS)
- **Giriş ekranı:** Açılışta sistem, yetki, motor, DNS-over-HTTPS ve ağ sayacı gerçekten kontrol
  edilir. Hepsi bitince **GİRİŞ** (ya da Enter) ana ekrana geçer. Bir kontrol uyarı verse de
  girilebilir. Bu bir kullanıcı adı/parola girişi değildir.
- **Çalışma süresi:** BAŞLAT'tan itibaren sayar; DURDUR'da son değerde durur, yeniden BAŞLAT'ta sıfırlanır.
  Sağ üstteki küçük yazı uygulamanın ne kadar süredir açık olduğunu gösterir.
- **Kullanılan internet:** Sayacın altında, oturum boyunca indirilen ↓ ve yüklenen ↑ veri (KB/MB/GB),
  anlık hız ve bir doluluk çubuğu. Çubuğun ölçeği toplama göre otomatik büyür
  (100 MB → 250 MB → 500 MB → 1 GB → 2 GB → …).
  - `psutil` kuruluysa (betikler kurar) bilgisayarın **tüm ağ trafiği** sayılır; sağ üstteki
    etiket "tüm ağ trafiği" der. Sanal arayüzler (loopback, VPN tünelleri) sayılmaz.
  - `psutil` yoksa yalnızca bu uygulamanın proxy/röle üzerinden geçirdiği veri sayılır;
    etiket "yalnızca uygulama üzerinden" der. Windows paket modunda uygulama tüm veriyi görmez,
    bu yüzden orada `psutil` gerekir.

## 1) Python kur (bir kez)
macOS 12'de hazır Python yok; Apple'ın Python'u eski Tk 8.5 içerir ve arayüz çalışmaz.
python.org → Downloads → macOS → **Python 3.12 (universal2 installer)** kur.

## 2) Çalıştır
`run.command` dosyasına çift tıkla. İlk seferde `.venv` kurulur (internet gerekir).

İndirilmiş dosyalar karantinaya alınır; "açılamıyor" derse sağ tık → **Aç**, ya da Terminal'de:

    cd <klasör>
    chmod +x *.command
    xattr -dr com.apple.quarantine .

## 3) İstersen .app üret
`build_mac.command` → klasörde `ProjectSieRra.app` oluşur (Dock ve menüde adı "Project : SieRra" görünür).
Uygulamayı çalıştıracağın Mac'te derle (Intel / Apple Silicon mimarisi derlediğin makineyle aynı olur).
Kendi derlediğin uygulamayı Gatekeeper engellemez.

## Nasıl çalışır
macOS'ta paket seviyesinde müdahale edilemediği için **yerel proxy** (127.0.0.1:8080) + DoH kullanılır.

- **BAŞLAT**'ta bir kez yönetici parolası istenir (sistem HTTPS proxy'sini açmak için).
- **DURDUR**, pencereyi kapatma ve Cmd+Q parola istemez; proxy otomatik kapanır.
  Uygulama çökse ya da zorla kapatılsa bile arka plandaki bekçi süreç proxy'yi kapatır.
- Yalnızca sistem proxy'sine uyan uygulamalar etkilenir (Safari, Chrome, Firefox).
- Güç seviyeleri macOS'ta kullanıcı alanı hileleridir: TCP parçalama, **TLS kaydı bölme**
  (ClientHello'yu iki TLS kaydına ayırır), sırasız gönderim ve OOB baytı. Sahte paket,
  RST bastırma ve QUIC engelleme Windows'a özgüdür (ham paket gerekir).
- Alan adları yalnızca DoH ile çözülür (Cloudflare, Google, Quad9). DoH ulaşılamazsa
  operatörün (zehirli olabilen) DNS'ine **düşülmez**; bağlantı hata verir ve tarayıcı tekrar dener.
- Proxy elle kapatılacaksa: Sistem Tercihleri › Ağ › Gelişmiş › Proxy'ler › Güvenli Web Proxy'si.
- Hata olursa: `~/ProjectSieRra_hata.txt`

## Uyumluluk sürümü
`ProjectSieRra_mac.spec` içindeki `MIN_MACOS = "12.7.6"` değeri `.app`'in istediği en düşük
macOS sürümüdür (Info.plist › LSMinimumSystemVersion). Daha eski sürümlerde de çalışsın
istersen bu değeri düşür.

## Roblox açılmıyorsa
1. Uygulamada **TANI**'ya bas (≈30 sn). Günlükte şunlardan biri çıkar:
   - `✘ SERTİFİKA GEÇERSİZ` → operatör, doğru IP'ye giderken bile seni engel sayfasına yönlendiriyor.
     Parçalama bunu aşamaz; o site için tünel (VPN / Cloudflare WARP) gerekir.
   - `✘ BAĞLANTI SIFIRLANDI` → SNI engeli. Sonraki adıma geç.
   - `DoH ... ✘` → DoH'a ulaşılamıyor. `certifi` eksikse `run.command`'ı yeniden çalıştır.
2. **OTOMATİK BUL**'a bas (≈1 dk). Uygulama, senin operatöründe 10 yöntemi sırayla gerçek
   sitelere karşı dener (Discord + Roblox) ve çalışanı **Otomatik** profiline kaydeder
   (`~/.projectsierra.json`; eski sürümün `~/.projectzvezda.json` dosyası da okunur). Sonra **Otomatik** seçili iken BAŞLAT.
3. Hiçbir yöntem çalışmazsa günlük bunu açıkça söyler: bu durumda kullanıcı alanı hileleri
   yetmiyordur (sahte paket gerekir) ya da engel IP düzeyindedir.

## Roblox uygulaması (Player) — "TlsVerificationFail" hatası
Roblox Player sistem proxy'sini kullanmaz; doğrudan bağlanır ve operatörün zehirli DNS'i onu
engel sayfasına götürür. Sertifika uyuşmadığı için `TlsVerificationFail` verir.
Bunun için **Uygulama desteği (Roblox/Discord)** anahtarı vardır (macOS'ta varsayılan açık):

1. **BAŞLAT**'ta yönetici parolası **bir kez** istenir (proxy ve DNS aynı pencerede).
2. `/etc/resolver/` içine Roblox ve Discord alan adları için kayıt yazılır; bu adların DNS
   sorguları uygulamanın yerel DNS yönlendiricisine (127.0.0.1:5300) gider.
3. **Roblox:** adlar `127.0.0.1`'e çözülür. Uygulama yerel röleye (443) bağlanır; röle SNI'yi okur,
   gerçek IP'yi DoH ile bulur, ClientHello'yu parçalayarak gerçek sunucuya gider. Sertifikayı
   uygulama gerçek sunucuyla doğrular (röle TLS'i açmaz).
4. **Discord:** adlar DoH ile doğru IP'ye çözülür (sesli sohbet sunucu adları dahil).
5. DURDUR, pencereyi kapatma ve Cmd+Q kayıtları siler. Uygulama çökse ya da zorla kapatılsa da
   arka plandaki bekçi süreç siler.

Doğrulama: uygulamayı BAŞLAT'tan sonra **TANI**'ya bas; en altta "Uygulama yolu (proxy'siz)"
bölümü çıkar. Orada `✔ Uygulamalar için yol açık` görmelisin. Sonra Roblox'u yeniden aç.

Bilmen gerekenler:
- Kayıtlar yalnızca bu uygulama açıkken vardır. **Mac yeniden başlarsa ya da elektrik giderse**
  silinemeyebilir; o zaman roblox.com / discord adları çözülmez. Uygulamayı bir kez açıp kapat ya da:
  `python3 dpibypass.py --cleanup-dns`  (veya `sudo rm -f /etc/resolver/roblox.com /etc/resolver/rbxcdn.com`
  vb. — içinde "# Project SieRra" (eski sürümde "# Project Zvezda") yazan dosyalar bizimdir).
- Kendi DNS'ini kullanan veya DoH'u uygulamasında gömülü uygulamalar `/etc/resolver`'ı görmez.
- 443 portu başka bir programda doluysa röle açılamaz; DNS yine doğru IP'leri verir ama parçalama
  olmaz (günlükte yazar).
- UDP trafiği (Roblox oyun sunucuları, Discord sesi) bu yolla parçalanmaz; yalnızca TCP/TLS.
- Anahtarı kapatırsan `/etc/resolver`'a hiç dokunulmaz.
