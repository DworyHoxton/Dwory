# -*- mode: python ; coding: utf-8 -*-
# macOS .app üretir:  python -m PyInstaller --noconfirm --clean ProjectSieRra_mac.spec
# (build_mac.command bunu senin yerine çalıştırır.)
import os
from PyInstaller.utils.hooks import collect_all

APP_NAME = "Project : SieRra"   # ekranda görünen ad (Dock/menü)
APP_FILE = "ProjectSieRra"      # .app dosya adı (iki nokta üst üste Finder'da sorun çıkarır)
MIN_MACOS = "12.7.6"      # Info.plist LSMinimumSystemVersion: uygulamanın istediği en düşük macOS
# None = derlediğin Mac'in mimarisi. İki mimariye birden istersen universal2 bir
# Python ile:  SIERRA_ARCH=universal2 ./build_mac.command
TARGET_ARCH = os.environ.get("SIERRA_ARCH") or None

datas, binaries, hiddenimports = [], [], []
for pkg in ("customtkinter", "certifi", "psutil"):
    d_, b_, h_ = collect_all(pkg)
    datas += d_
    binaries += b_
    hiddenimports += h_

a = Analysis(
    ["dpibypass_gui.py"],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["pydivert"],     # yalnızca Windows paket modunda kullanılır
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="ProjectSieRra",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=TARGET_ARCH,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False,
               name="ProjectSieRra")

app = BUNDLE(
    coll,
    name=APP_FILE + ".app",
    icon=None,
    bundle_identifier="com.dwory.projectsierra",
    info_plist={
        "CFBundleName": APP_NAME,
        "CFBundleDisplayName": APP_NAME,
        "CFBundleShortVersionString": "2.9",
        "CFBundleVersion": "2.9.0",
        "LSMinimumSystemVersion": MIN_MACOS,
        "NSHighResolutionCapable": True,
        "LSApplicationCategoryType": "public.app-category.utilities",
        "NSHumanReadableCopyright": "by Dwory",
    },
)
