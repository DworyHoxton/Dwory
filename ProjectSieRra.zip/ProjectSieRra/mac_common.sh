#!/bin/bash
# Ortak yardımcılar. macOS 12.7.6 uyumlu: bash 3.2 ve BSD araçlarıyla çalışır.

# $1 = python yolu. Python >= 3.9 ve Tcl/Tk >= 8.6 ise 0 döner.
py_ok() {
  "$1" -c 'import sys, tkinter; sys.exit(0 if sys.version_info >= (3, 9) and tkinter.TkVersion >= 8.6 else 1)' >/dev/null 2>&1
}

# Uygun Python'u bulup PY değişkenine yazar. Yoksa 1 döner.
find_python() {
  PY=""
  local c v
  for v in 3.13 3.12 3.11 3.10 3.14; do          # python.org kurulumları
    c="/Library/Frameworks/Python.framework/Versions/$v/bin/python3"
    if [ -x "$c" ] && py_ok "$c"; then PY="$c"; return 0; fi
  done
  for c in /opt/homebrew/bin/python3 /usr/local/bin/python3; do   # Homebrew
    if [ -x "$c" ] && py_ok "$c"; then PY="$c"; return 0; fi
  done
  # Apple'ın Python'u yalnızca Komut Satırı Araçları kuruluysa denenir
  # (kurulu değilken çağırmak "geliştirici araçlarını kur" penceresi açar).
  if xcode-select -p >/dev/null 2>&1 && [ -x /usr/bin/python3 ] && py_ok /usr/bin/python3; then
    PY=/usr/bin/python3; return 0
  fi
  return 1
}

no_python() {
  echo
  echo "Uygun Python bulunamadı (Python 3.9+ ve Tcl/Tk 8.6 gerekli)."
  echo "macOS 12'de hazır Python yoktur; Apple'ın Python'u ise eski Tk 8.5 içerir"
  echo "ve arayüz onunla çalışmaz."
  echo
  echo "  1) https://www.python.org/downloads/macos/ adresinden Python 3.12"
  echo "     ('macOS 64-bit universal2 installer') indirip kur."
  echo "  2) Bu dosyayı tekrar çalıştır."
}

# Proje klasöründe .venv oluşturur ve verilen pip paketlerini kurar.
setup_venv() {
  VENV="$PWD/.venv"
  if [ -x "$VENV/bin/python" ] && ! py_ok "$VENV/bin/python"; then
    rm -rf "$VENV"      # klasör taşınmış ya da Python kaldırılmış olabilir
  fi
  if [ ! -x "$VENV/bin/python" ]; then
    echo "Sanal ortam oluşturuluyor (.venv)..."
    "$PY" -m venv "$VENV" || return 1
  fi
  echo "Paketler kontrol ediliyor: $*"
  "$VENV/bin/python" -m pip install --quiet --disable-pip-version-check --upgrade pip || return 1
  "$VENV/bin/python" -m pip install --quiet --disable-pip-version-check "$@" || return 1
}
