#!/bin/bash
# Project : SieRra - macOS: çift tıkla çalıştır (run.bat'ın karşılığı).
cd "$(dirname "$0")" || exit 1
. ./mac_common.sh

pause() { read -n 1 -s -r -p "Kapatmak için bir tuşa bas..."; echo; }

echo "=============================================="
echo "  Project : SieRra - macOS"
echo "=============================================="

if ! find_python; then no_python; pause; exit 1; fi
echo "Python: $PY"

if ! setup_venv customtkinter certifi psutil; then
  echo "Paket kurulumu başarısız. İnternet bağlantını kontrol et."
  pause; exit 1
fi

echo "Project : SieRra başlatılıyor..."
"$VENV/bin/python" dpibypass_gui.py
rc=$?
if [ $rc -ne 0 ]; then
  echo
  echo "Uygulama hata ile kapandı (kod $rc). Ayrıntı: ~/ProjectSieRra_hata.txt"
  pause
fi
exit $rc
