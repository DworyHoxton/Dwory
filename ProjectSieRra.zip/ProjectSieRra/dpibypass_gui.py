#!/usr/bin/env python3
"""
Project : SieRra - modern arayuz (customtkinter), siyah-kirmizi tema.
dpibypass.py ile ayni klasorde olmalidir.

Kurulum:   pip install customtkinter pydivert psutil    (Windows)
           pip install customtkinter certifi psutil     (macOS 12.7.6+)
Calistirma: python dpibypass_gui.py
macOS:     run.command (calistir)  /  build_mac.command (.app uret)
"""
import asyncio
import atexit
import ctypes
import errno
import os
import platform
import queue
import subprocess
import sys
import threading
import time
import traceback

import customtkinter as ctk

import dpibypass as d

SYSTEM = platform.system()

APP_TITLE = "Project : SieRra"
APP_VERSION = "2.9"

# ---- tema: siyah + kirmizi
BG = "#050505"            # pencere
SURFACE = "#0e0e10"       # kartlar
SURFACE2 = "#17171b"      # girdi/dugme zemini
BORDER = "#26262c"
BORDER_HI = "#3a3a43"
TEXT = "#f5f5f7"
MUTED = "#8e8e99"
DIM = "#5b5b66"
ACCENT = "#ef233c"        # ana kirmizi
ACCENT_H = "#d90429"
ACCENT_D = "#2a0b10"      # koyu kirmizi dolgu (calisirken dugme)
ACCENT_DH = "#3d1119"
GREEN = "#2ecc71"
AMBER = "#f5a623"
AMBER_D = "#2b1f08"
RADIUS = 14               # kart koseleri
MONO = "Menlo" if SYSTEM == "Darwin" else "Consolas"

ST_OFF, ST_ON, ST_STOP = "● KAPALI", "● AKTİF", "● DURDURULUYOR"

PROFILE_LABELS_WIN = {"Hafif": "hafif", "Dengeli": "dengeli",
                      "Güçlü": "guclu", "Maksimum": "maksimum"}
PROFILE_INFO = {
    "Hafif": "Yalnızca TLS paketini SNI'nin ortasından böler. En az müdahale.",
    "Dengeli": "Paketi bölüp ters sırada yollar, bozuk checksum'lu sahte paket ekler. "
               "Çoğu operatör için iyi başlangıç.",
    "Güçlü": "Dengeli'ye ek olarak sunucunun reddedeceği bozuk sıra numaralı "
             "sahte paket gönderir. Dengeli işe yaramazsa dene.",
    "Maksimum": "Tüm teknikler birlikte. Sunucuya ulaşmayacak şekilde ölçülen "
                "TTL'li sahte paket de eklenir. Son çare.",
}
# macOS proxy modunda ham paket gonderilemez; yontemler kullanici alani TCP/TLS
# hileleridir (parcalama, TLS kaydi bolme, siralama bozma, OOB).
PROFILE_LABELS_MAC = {"Hafif": "hafif", "Dengeli": "dengeli", "Güçlü": "guclu",
                      "Maksimum": "maksimum", "TLS+": "tlsplus",
                      "Otomatik": "otomatik"}
PROFILE_INFO_MAC = {
    "Hafif": "TLS paketini SNI'nin ortasından böler. En az müdahale.",
    "Dengeli": "İlk baytı ayırır, sonra SNI'nin ortasından böler. Çoğu "
               "operatör için iyi başlangıç.",
    "Güçlü": "Paketi SNI'nin başı ve ortası dahil birkaç parçaya böler. "
             "Dengeli işe yaramazsa dene.",
    "Maksimum": "En çok parçalama; her bağlantıya biraz gecikme ekler.",
    "TLS+": "ClientHello'yu iki TLS kaydına böler ve TCP'yi de keser. Birçok DPI "
            "kayıtları birleştirmez. Roblox'ta Hafif/Dengeli yetmediğinde dene.",
    "Otomatik": "OTOMATİK BUL'un senin operatöründe gerçekten çalışırken bulduğu "
                "yöntem. Önce OTOMATİK BUL'a bas.",
}
PROFILE_LABELS = PROFILE_LABELS_MAC if SYSTEM == "Darwin" else PROFILE_LABELS_WIN
INFO = PROFILE_INFO_MAC if SYSTEM == "Darwin" else PROFILE_INFO
STAT_CARDS = ([("hello", "Bölünen TLS"), ("dns", "DoH yanıtı"),
               ("conn", "Bağlantı"), ("err", "Hata")]
              if SYSTEM == "Darwin" else
              [("hello", "Bölünen TLS"), ("fake", "Sahte paket"),
               ("rst", "RST bastırıldı"), ("dns", "DNS yanıtı")])


# ----------------------------------------------------------------------------
def ensure_admin_windows():
    if SYSTEM != "Windows":
        return
    try:
        if ctypes.windll.shell32.IsUserAnAdmin():
            return
    except Exception:
        return
    exe = sys.executable
    if getattr(sys, "frozen", False):
        args = sys.argv[1:]
    else:
        pw = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(pw):
            exe = pw  # konsol penceresi acilmasin
        args = [os.path.abspath(sys.argv[0])] + sys.argv[1:]
    params = " ".join(f'"{x}"' for x in args)
    rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params,
                                             os.getcwd(), 1)
    if rc <= 32:  # kullanici UAC'yi reddetti / baslatilamadi
        sys.exit("Yonetici izni verilmedi.")
    sys.exit()


class QWriter:
    """print() ciktisini log paneline yonlendirir."""

    def __init__(self, q):
        self.q = q

    def write(self, s):
        if s and s.strip():
            self.q.put(s.rstrip())

    def flush(self):
        pass


# ----------------------------------------------------------------------------
# Arka plan motoru
# ----------------------------------------------------------------------------
class Engine:
    def __init__(self):
        self.thread = None
        self.mode = None
        self.args = None
        self.w = None
        self.loop = None
        self.task = None

    def alive(self):
        return self.thread is not None and self.thread.is_alive()

    def start(self, mode, args):
        self.mode, self.args = mode, args
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        try:
            if self.mode == "packet" and self.w is not None:
                self.w.close()
            elif self.loop is not None and self.task is not None:
                self.loop.call_soon_threadsafe(self.task.cancel)
        except Exception:
            pass

    def _run(self):
        try:
            if self.mode == "packet":
                self._run_packet()
            else:
                self._run_proxy()
        except Exception as e:
            print(f"[!] {e!r}")
        finally:
            print("Durduruldu.")

    def _run_packet(self):
        try:
            import pydivert
        except ImportError:
            print("pydivert yok. Kur:  pip install pydivert")
            return
        a = self.args
        d.DOH_URL = a.doh
        d.flush_dns()
        with pydivert.WinDivert(d.make_filter(a.dns, a.rst_drop,
                                              a.block_quic)) as w:
            self.w = w
            print("Paket modu aktif (sistem geneli).")
            try:
                for pkt in w:
                    try:
                        d.process(w, pkt, a)
                    except Exception as e:
                        print(f"[!] {e!r}")
                        w.send(pkt)
            except Exception:
                pass  # w.close() cagrilinca buraya duser

    def _run_proxy(self):
        a = self.args
        d.DOH_URL = a.doh
        use_sys = ((a.system_proxy or getattr(a, "app_dns", False))
                   and SYSTEM == "Darwin")
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        try:
            self.loop.run_until_complete(self._serve(use_sys))
        except Exception as e:
            print(f"[!] {e!r}")
        finally:
            try:
                pending = asyncio.all_tasks(self.loop)
                for t in pending:
                    t.cancel()
                self.loop.run_until_complete(
                    asyncio.gather(*pending, return_exceptions=True))
            except Exception:
                pass
            self.loop.close()
            if use_sys:
                d.mac_proxy_off()  # kendi mesajini yazar

    async def _serve(self, use_sys=False):
        a = self.args
        self.task = asyncio.current_task()
        try:
            try:
                server = await asyncio.start_server(
                    lambda r, w: d.handle(r, w, a), a.host, a.port)
            except OSError as e:
                if e.errno == errno.EADDRINUSE:
                    print(f"Port {a.port} başka bir program tarafından "
                          "kullanılıyor; proxy başlatılamadı.")
                else:
                    print(f"Proxy {a.host}:{a.port} açılamadı: {e}")
                return
            print(f"Proxy modu aktif: {a.host}:{a.port}")
            svc = (d.AppDnsService()
                   if SYSTEM == "Darwin" and getattr(a, "app_dns", False) else None)
            try:
                async with server:
                    if svc is not None and not await svc.start(a):
                        svc = None
                    use_proxy = bool(a.system_proxy and SYSTEM == "Darwin")
                    if use_proxy or svc is not None:
                        # Port bağlandıktan sonra aç; parola penceresi arayüzü kilitlemez.
                        loop = asyncio.get_running_loop()
                        await loop.run_in_executor(
                            None, d.mac_system_on, a.host, a.port, use_proxy,
                            svc.port if svc is not None else None)
                    await server.serve_forever()
            finally:
                if svc is not None:
                    svc.close()
        except asyncio.CancelledError:
            pass


# ----------------------------------------------------------------------------
# Arayuz
# ----------------------------------------------------------------------------
class Card(ctk.CTkFrame):
    def __init__(self, master, **kw):
        kw.setdefault("fg_color", SURFACE)
        kw.setdefault("corner_radius", RADIUS)
        kw.setdefault("border_width", 1)
        kw.setdefault("border_color", BORDER)
        super().__init__(master, **kw)


def caption(master, text):
    return ctk.CTkLabel(master, text=text, text_color=MUTED,
                        font=ctk.CTkFont(size=11, weight="bold"))


def pill_button(master, text, command, width=100, accent=False, height=34):
    return ctk.CTkButton(
        master, text=text, command=command, width=width, height=height,
        corner_radius=10, border_width=1,
        border_color=ACCENT if accent else BORDER_HI,
        fg_color=ACCENT if accent else SURFACE2,
        hover_color=ACCENT_H if accent else BORDER_HI,
        text_color="white" if accent else TEXT, text_color_disabled=DIM,
        font=ctk.CTkFont(size=12, weight="bold"))


class ProfilePicker(ctk.CTkFrame):
    """Yuvarlak kose, iki sutunlu profil secici (get/set/configure(state=) arayuzu)."""

    def __init__(self, master, labels, command, cols=2):
        super().__init__(master, fg_color="transparent")
        self._cb = command
        self._value = None
        self._btns = {}
        for c in range(cols):
            self.grid_columnconfigure(c, weight=1, uniform="p")
        for i, lab in enumerate(labels):
            b = ctk.CTkButton(
                self, text=lab, height=40, corner_radius=10, border_width=1,
                border_color=BORDER, fg_color=SURFACE2, hover_color=BORDER_HI,
                text_color=TEXT, text_color_disabled=DIM,
                font=ctk.CTkFont(size=13, weight="bold"),
                command=lambda l=lab: self._click(l))
            b.grid(row=i // cols, column=i % cols, sticky="ew", pady=3,
                   padx=(0, 3) if i % cols == 0 else (3, 0))
            self._btns[lab] = b

    def _click(self, lab):
        self.set(lab)
        self._cb(lab)

    def set(self, lab):
        self._value = lab
        for l, b in self._btns.items():
            sel = (l == lab)
            b.configure(fg_color=ACCENT if sel else SURFACE2,
                        border_color=ACCENT if sel else BORDER,
                        hover_color=ACCENT_H if sel else BORDER_HI,
                        text_color="white" if sel else TEXT,
                        text_color_disabled="#ffc2c9" if sel else DIM)

    def get(self):
        return self._value

    def configure(self, **kw):
        state = kw.pop("state", None)
        if state is not None:
            for b in self._btns.values():
                b.configure(state=state)
        if kw:
            super().configure(**kw)


CHECKS = [("sys", "Sistem"), ("auth", "Yetki"), ("engine", "Motor"),
          ("doh", "DNS-over-HTTPS"), ("net", "Ağ sayacı")]


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.q = queue.Queue()
        self.engine = None
        self.opened_at = time.time()
        self.started_at = 0.0
        self.warned = False
        self._state = "off"
        self._busy = False
        self._done = queue.Queue()
        self._auto_res = None
        self.net = d.NetMeter()
        self._chk_q = queue.Queue()
        self._chk_n = 0
        self._chk_done = False
        self._chk_target = 0.0
        self._prog_shown = 0.0
        self._entered = False
        sys.stdout = QWriter(self.q)
        sys.stderr = QWriter(self.q)

        ctk.set_appearance_mode("dark")
        self.title(APP_TITLE)
        self.geometry("1000x780")
        self.minsize(940, 740)
        self.configure(fg_color=BG)

        self.login = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        self.main = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        self._build_login()
        self._build_main()
        self.login.pack(fill="both", expand=True)   # once giris ekrani
        self.set_state("off")

        self.bind("<Return>", self._on_return)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        if SYSTEM == "Darwin":
            try:  # Cmd+Q de düzgün kapanış yolundan geçsin
                self.createcommand("::tk::mac::Quit", self.on_close)
            except Exception:
                pass
            atexit.register(d.mac_proxy_off)  # son güvence (zaten bir kez kapanırsa no-op)
        threading.Thread(target=self._run_checks, daemon=True).start()
        self.after(40, self._anim)
        self.after(200, self.poll)

    # ------------------------------------------------------------ giris ekrani
    def _build_login(self):
        center = ctk.CTkFrame(self.login, fg_color="transparent")
        center.place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkLabel(center, text="PROJECT :", text_color=MUTED,
                     font=ctk.CTkFont(size=22, weight="bold")).pack()
        ctk.CTkLabel(center, text="SieRra", text_color=ACCENT,
                     font=ctk.CTkFont(size=78, weight="bold")).pack(pady=(0, 2))
        ctk.CTkLabel(center, text="DPI atlatma  •  DNS koruması  •  Roblox & Discord",
                     text_color=DIM, font=ctk.CTkFont(size=13)).pack(pady=(0, 26))

        card = Card(center, width=480)
        card.pack()
        self.chk_rows = {}
        for i, (key, name) in enumerate(CHECKS):
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=24, pady=(18 if i == 0 else 4, 4))
            icon = ctk.CTkLabel(row, text="○", text_color=DIM, width=24,
                                font=ctk.CTkFont(size=16, weight="bold"))
            icon.pack(side="left")
            ctk.CTkLabel(row, text=name, text_color=TEXT, width=130, anchor="w",
                         font=ctk.CTkFont(size=13, weight="bold")).pack(side="left")
            det = ctk.CTkLabel(row, text="bekleniyor", text_color=DIM, anchor="e",
                               font=ctk.CTkFont(size=12))
            det.pack(side="right")
            self.chk_rows[key] = (icon, det)
        self.prog = ctk.CTkProgressBar(card, height=6, corner_radius=3,
                                       fg_color=SURFACE2, progress_color=ACCENT)
        self.prog.set(0)
        self.prog.pack(fill="x", padx=24, pady=(16, 8))
        self.chk_status = ctk.CTkLabel(card, text="Kontroller çalışıyor...",
                                       text_color=MUTED, font=ctk.CTkFont(size=12))
        self.chk_status.pack(pady=(0, 18))

        self.enter_btn = ctk.CTkButton(
            center, text="GİRİŞ", width=320, height=54, corner_radius=14,
            fg_color=ACCENT_D, hover_color=ACCENT_H, border_width=1,
            border_color=BORDER_HI, text_color="white", text_color_disabled=DIM,
            font=ctk.CTkFont(size=17, weight="bold"), state="disabled",
            command=self.enter)
        self.enter_btn.pack(pady=(26, 10))
        ctk.CTkLabel(center, text=f"by Dwory  •  v{APP_VERSION}  •  {SYSTEM}",
                     text_color=DIM, font=ctk.CTkFont(size=11)).pack()

    def _run_checks(self):
        """Arka planda gercek kontroller; sonuclar kuyruga yazilir."""
        def step(key, ok, detail):
            self._chk_q.put((key, ok, detail))
            time.sleep(0.18)
        step("sys", True, f"{SYSTEM} {platform.release()}")
        if SYSTEM == "Windows":
            try:
                admin = bool(ctypes.windll.shell32.IsUserAnAdmin())
            except Exception:
                admin = False
            step("auth", admin, "Yönetici" if admin else "Yönetici değil (paket modu çalışmaz)")
        else:
            step("auth", True, "Standart kullanıcı, parola gerektiğinde sorulur")
        if SYSTEM == "Windows":
            try:
                import pydivert  # noqa: F401
                step("engine", True, "WinDivert paket modu hazır")
            except Exception:
                step("engine", False, "pydivert yok: pip install pydivert")
        else:
            step("engine", True, "Yerel proxy modu hazır")
        t0 = time.time()
        try:
            ips = d.doh_resolve("discord.com")
        except Exception:
            ips = None
        ms = int((time.time() - t0) * 1000)
        step("doh", bool(ips),
             f"Erişilebilir ({ms} ms)" if ips else "DoH'a ulaşılamadı (ağ ya da engel?)")
        try:
            src = d.NetMeter().source
        except Exception:
            src = "uygulama"
        step("net", src == "sistem",
             "Tüm ağ trafiği izleniyor" if src == "sistem"
             else "psutil yok: yalnızca uygulama trafiği")
        self._chk_q.put(("done", True, ""))

    def _drain_checks(self):
        try:
            while True:
                key, ok, detail = self._chk_q.get_nowait()
                if key == "done":
                    self._chk_done = True
                    self._chk_target = 1.0
                    warn = self._chk_warn
                    self.chk_status.configure(
                        text=("Hazır" if not warn else
                              "Bazı kontroller uyarı verdi; yine de girebilirsin"),
                        text_color=GREEN if not warn else AMBER)
                    self.enter_btn.configure(state="normal", fg_color=ACCENT,
                                             border_color=ACCENT)
                    continue
                icon, det = self.chk_rows[key]
                icon.configure(text="✓" if ok else "!",
                               text_color=GREEN if ok else AMBER)
                det.configure(text=detail, text_color=MUTED if ok else AMBER)
                self._chk_n += 1
                if not ok:
                    self._chk_warn = True
                self._chk_target = self._chk_n / len(CHECKS) * 0.95
        except queue.Empty:
            pass

    _chk_warn = False

    def _anim(self):
        if self._entered:
            return
        tgt = self._chk_target
        self._prog_shown += (tgt - self._prog_shown) * 0.18
        if abs(tgt - self._prog_shown) < 0.002:
            self._prog_shown = tgt
        self.prog.set(self._prog_shown)
        self.after(40, self._anim)

    def _on_return(self, _event=None):
        if not self._entered:
            self.enter()

    def enter(self):
        if self._entered or not self._chk_done:
            return
        self._entered = True
        self.login.pack_forget()
        self.main.pack(fill="both", expand=True)
        self.log_line(f"Hazır. Sistem: {SYSTEM}")

    # --------------------------------------------------------------- ana ekran
    def _build_main(self):
        m = self.main
        m.grid_columnconfigure(0, weight=0)
        m.grid_columnconfigure(1, weight=1)
        m.grid_rowconfigure(1, weight=1)
        self._build_header()
        self._build_left()
        self._build_right()

    def _build_header(self):
        h = ctk.CTkFrame(self.main, fg_color="transparent")
        h.grid(row=0, column=0, columnspan=2, sticky="ew", padx=28, pady=(20, 6))
        ctk.CTkLabel(h, text="S", width=42, height=42, corner_radius=11,
                     fg_color=ACCENT, text_color="white",
                     font=ctk.CTkFont(size=22, weight="bold")).pack(side="left")
        ctk.CTkLabel(h, text="Project :", text_color=MUTED,
                     font=ctk.CTkFont(size=20, weight="bold")).pack(side="left", padx=(12, 6))
        ctk.CTkLabel(h, text="SieRra", text_color=ACCENT,
                     font=ctk.CTkFont(size=30, weight="bold")).pack(side="left")
        ctk.CTkLabel(h, text=f"  v{APP_VERSION}  by Dwory", text_color=DIM,
                     font=ctk.CTkFont(size=12)).pack(side="left", pady=(12, 0))
        self.status = ctk.CTkLabel(h, text=ST_OFF, text_color=MUTED, width=140,
                                   height=30, corner_radius=15, fg_color=SURFACE2,
                                   font=ctk.CTkFont(size=12, weight="bold"))
        self.status.pack(side="right")
        ctk.CTkLabel(h, text=SYSTEM.upper(), text_color=MUTED, width=90, height=30,
                     corner_radius=15, fg_color=SURFACE2,
                     font=ctk.CTkFont(size=11, weight="bold")).pack(side="right", padx=(0, 8))

    def _build_left(self):
        left = ctk.CTkFrame(self.main, fg_color="transparent", width=340)
        left.grid(row=1, column=0, sticky="ns", padx=(28, 12), pady=(8, 24))
        left.grid_propagate(False)
        left.pack_propagate(False)      # içerik pack ile dizildiği için genişlik sabit kalsın

        ctrl = Card(left)
        ctrl.pack(fill="x")
        self.power = ctk.CTkButton(
            ctrl, text="BAŞLAT", height=78, corner_radius=14, border_width=2,
            fg_color=ACCENT, hover_color=ACCENT_H, border_color=ACCENT,
            text_color="white", font=ctk.CTkFont(size=22, weight="bold"),
            command=self.toggle)
        self.power.pack(fill="x", padx=18, pady=(18, 10))
        self.hint = ctk.CTkLabel(ctrl, text="Korumayı başlatmak için dokun",
                                 text_color=MUTED, font=ctk.CTkFont(size=12))
        self.hint.pack(pady=(0, 16))

        pc = Card(left)
        pc.pack(fill="x", pady=(14, 0))
        caption(pc, "GÜÇ SEVİYESİ").pack(anchor="w", padx=20, pady=(16, 0))
        self.profile = ProfilePicker(pc, list(PROFILE_LABELS), self.on_profile)
        self.profile.set("Dengeli")
        self.profile.pack(fill="x", padx=16, pady=(8, 4))
        self.info = ctk.CTkLabel(pc, text=INFO["Dengeli"], text_color=MUTED,
                                 wraplength=280, justify="left",
                                 font=ctk.CTkFont(size=12))
        self.info.pack(anchor="w", padx=20, pady=(4, 8))
        if SYSTEM == "Darwin":
            ctk.CTkLabel(
                pc, text="macOS'ta proxy modunda çalışır: sistem proxy'sine uyan "
                         "uygulamalar (Safari, Chrome, Firefox) etkilenir. Proxy'yi "
                         "kullanmayan uygulamalar (ör. Roblox Player) için 'Uygulama "
                         "desteği' anahtarını aç: yönetici parolası bir kez istenir, "
                         "DNS ve bağlantı yerelden yönlendirilir.",
                text_color=DIM, wraplength=280, justify="left",
                font=ctk.CTkFont(size=11)).pack(anchor="w", padx=20, pady=(0, 6))
        ctk.CTkFrame(pc, height=8, fg_color="transparent").pack()

    def _build_right(self):
        right = ctk.CTkFrame(self.main, fg_color="transparent")
        right.grid(row=1, column=1, sticky="nsew", padx=(12, 28), pady=(8, 24))
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure(3, weight=1)

        # --- calisma suresi + kullanilan internet
        sess = Card(right)
        sess.grid(row=0, column=0, sticky="ew")
        sess.grid_columnconfigure(0, weight=1)
        top = ctk.CTkFrame(sess, fg_color="transparent")
        top.grid(row=0, column=0, sticky="ew", padx=22, pady=(16, 0))
        caption(top, "ÇALIŞMA SÜRESİ").pack(side="left")
        self.app_open_lbl = ctk.CTkLabel(top, text="Uygulama açık 00:00:00",
                                         text_color=DIM, font=ctk.CTkFont(size=11))
        self.app_open_lbl.pack(side="right")
        self.timer = ctk.CTkLabel(sess, text="00:00:00", text_color=MUTED,
                                  font=ctk.CTkFont(family=MONO, size=58, weight="bold"))
        self.timer.grid(row=1, column=0, sticky="w", padx=22, pady=(0, 6))
        ctk.CTkFrame(sess, height=1, fg_color=BORDER).grid(
            row=2, column=0, sticky="ew", padx=22, pady=(2, 10))

        dh = ctk.CTkFrame(sess, fg_color="transparent")
        dh.grid(row=3, column=0, sticky="ew", padx=22)
        caption(dh, "KULLANILAN İNTERNET").pack(side="left")
        self.data_src = ctk.CTkLabel(dh, text="", text_color=DIM, font=ctk.CTkFont(size=10))
        self.data_src.pack(side="right")
        dv = ctk.CTkFrame(sess, fg_color="transparent")
        dv.grid(row=4, column=0, sticky="ew", padx=22, pady=(2, 0))
        self.data_total = ctk.CTkLabel(dv, text="0 B", text_color=TEXT,
                                       font=ctk.CTkFont(size=28, weight="bold"))
        self.data_total.pack(side="left")
        self.data_limit = ctk.CTkLabel(dv, text="/ 100 MB", text_color=MUTED,
                                       font=ctk.CTkFont(size=14))
        self.data_limit.pack(side="left", padx=(8, 0), pady=(8, 0))
        self.data_detail = ctk.CTkLabel(dv, text="↓ 0 B    ↑ 0 B    0 B/s",
                                        text_color=MUTED, font=ctk.CTkFont(size=12))
        self.data_detail.pack(side="right", pady=(8, 0))
        self.data_bar = ctk.CTkProgressBar(sess, height=12, corner_radius=6,
                                           fg_color=SURFACE2, progress_color=ACCENT)
        self.data_bar.set(0)
        self.data_bar.grid(row=5, column=0, sticky="ew", padx=22, pady=(8, 18))

        # --- istatistik kartlari
        stats = ctk.CTkFrame(right, fg_color="transparent")
        stats.grid(row=1, column=0, sticky="ew", pady=(12, 0))
        stats.grid_columnconfigure((0, 1, 2, 3), weight=1, uniform="s")
        self.stat_labels = {}
        for i, (key, cap) in enumerate(STAT_CARDS):
            card = Card(stats)
            card.grid(row=0, column=i, sticky="ew",
                      padx=(0 if i == 0 else 5, 0 if i == 3 else 5))
            val = ctk.CTkLabel(card, text="0", text_color=TEXT,
                               font=ctk.CTkFont(size=24, weight="bold"))
            val.pack(pady=(12, 0))
            ctk.CTkLabel(card, text=cap, text_color=MUTED,
                         font=ctk.CTkFont(size=11)).pack(pady=(0, 11))
            self.stat_labels[key] = val

        # --- secenekler
        sw = Card(right)
        sw.grid(row=2, column=0, sticky="ew", pady=(12, 12))
        self.dns_var = ctk.IntVar(value=1)
        self.rst_var = ctk.IntVar(value=1)
        self.quic_var = ctk.IntVar(value=1)
        self.sys_var = ctk.IntVar(value=1 if SYSTEM == "Darwin" else 0)
        self.app_var = ctk.IntVar(value=1 if SYSTEM == "Darwin" else 0)
        self.switches = []
        items = [("DNS koruması (DoH)", self.dns_var)]
        if SYSTEM == "Darwin":
            items.append(("macOS sistem proxy'si", self.sys_var))
            items.append(("Uygulama desteği (Roblox/Discord)", self.app_var))
        else:  # paket modu secenekleri (macOS'ta karsiligi yok)
            items += [("Sahte RST'leri bastır", self.rst_var),
                      ("QUIC'i engelle (HTTP/3)", self.quic_var)]
        for i, (text, var) in enumerate(items):
            s = ctk.CTkSwitch(
                sw, text=text, variable=var, onvalue=1, offvalue=0,
                progress_color=ACCENT, button_color=TEXT,
                button_hover_color="#ffffff", fg_color=BORDER_HI,
                text_color=TEXT, font=ctk.CTkFont(size=13))
            s.grid(row=i // 2, column=i % 2, sticky="w", padx=22, pady=11)
            self.switches.append(s)
        sw.grid_columnconfigure((0, 1), weight=1)

        # --- gunluk + araclar
        box = Card(right)
        box.grid(row=3, column=0, sticky="nsew")
        box.grid_rowconfigure(1, weight=1)
        box.grid_columnconfigure(0, weight=1)
        bt = ctk.CTkFrame(box, fg_color="transparent")
        bt.grid(row=0, column=0, sticky="ew", padx=16, pady=(12, 0))
        caption(bt, "GÜNLÜK").pack(side="left")
        self.tools = []
        self.diag_btn = pill_button(bt, "TANI", self.run_diag, 70)
        self.diag_btn.pack(side="right")
        self.tools.append(self.diag_btn)
        if SYSTEM == "Darwin":
            self.auto_btn = pill_button(bt, "OTOMATİK BUL", self.run_auto, 130,
                                        accent=True)
            self.auto_btn.pack(side="right", padx=(0, 8))
            self.tools.append(self.auto_btn)
        self.log = ctk.CTkTextbox(
            box, fg_color=SURFACE, text_color=TEXT, border_width=0,
            corner_radius=10, font=ctk.CTkFont(family=MONO, size=12), wrap="word")
        self.log.grid(row=1, column=0, sticky="nsew", padx=10, pady=(6, 10))
        self.log.configure(state="disabled")

    # --- yardimcilar
    def log_line(self, text):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def on_profile(self, value):
        self.info.configure(text=INFO[value])
        if (SYSTEM == "Darwin" and value == "Otomatik"
                and not os.path.exists(d.AUTO_PATH)
                and not os.path.exists(d.AUTO_PATH_OLD)):
            self.log_line("Otomatik profil henüz ayarlanmadı: önce OTOMATİK BUL'a bas.")

    def running(self):
        return self.engine is not None and self.engine.alive()

    def set_state(self, state):
        """state: 'off' | 'on' | 'stopping'"""
        prev = self._state
        self._state = state
        if state == "on":
            self.power.configure(text="DURDUR", fg_color=ACCENT_D,
                                 hover_color=ACCENT_DH, border_color=ACCENT,
                                 text_color=TEXT)
            self.status.configure(text=ST_ON, text_color=GREEN)
            self.hint.configure(text="Koruma aktif. Durdurmak için dokun.")
            self.timer.configure(text_color=TEXT)
        elif state == "stopping":
            self.power.configure(text="...", fg_color=AMBER_D, hover_color=AMBER_D,
                                 border_color=AMBER, text_color=AMBER)
            self.status.configure(text=ST_STOP, text_color=AMBER)
            self.hint.configure(text="Durduruluyor...")
        else:
            if prev in ("on", "stopping") and self.started_at:
                self.timer.configure(
                    text=d.fmt_hms(time.time() - self.started_at))   # son sureyi dondur
            self.power.configure(text="BAŞLAT", fg_color=ACCENT,
                                 hover_color=ACCENT_H, border_color=ACCENT,
                                 text_color="white")
            self.status.configure(text=ST_OFF, text_color=MUTED)
            self.hint.configure(text="Korumayı başlatmak için dokun")
            self.timer.configure(text_color=MUTED)
        lock = "disabled" if state != "off" else "normal"
        self.profile.configure(state=lock)
        for s in self.switches:
            s.configure(state=lock)

    def _set_tools(self, state):
        for b in self.tools:
            b.configure(state=state)

    def _bg(self, name, fn):
        """Tani / otomatik arama arka planda calisir (arayuz donmasin)."""
        if self._busy:
            return
        self._busy = True
        self._set_tools("disabled")

        def run():
            try:
                fn()
            except Exception as e:
                print(f"[!] {e!r}")
            finally:
                self._busy = False
                self._done.put(name)
        threading.Thread(target=run, daemon=True).start()

    def run_diag(self):
        st = (d.strategy_for(PROFILE_LABELS[self.profile.get()])
              if SYSTEM == "Darwin" else None)
        self.log_line("Tanı çalışıyor (yaklaşık 15-30 sn)...")
        self._bg("diag", lambda: d.diagnose(strategy=st))

    def run_auto(self):
        self.log_line("Otomatik arama çalışıyor (yaklaşık 1 dk)...")
        self._auto_res = None

        def job():
            self._auto_res = d.autotune()
        self._bg("auto", job)

    # --- eylemler
    def toggle(self):
        if self.running():
            self.set_state("stopping")
            self.engine.stop()
        else:
            self.start()

    def start(self):
        mode = "packet" if SYSTEM == "Windows" else "proxy"
        key = PROFILE_LABELS[self.profile.get()]
        args = d.make_args(
            key,
            dns=bool(self.dns_var.get()),
            rst_drop=bool(self.rst_var.get()),
            block_quic=bool(self.quic_var.get()),
            system_proxy=bool(self.sys_var.get()),
            app_dns=bool(self.app_var.get()),
        )
        for k in d.STATS:
            d.STATS[k] = 0
        self.net.reset()
        self.log_line(f"Profil: {self.profile.get()}")
        self.engine = Engine()
        self.engine.start(mode, args)
        self.started_at = time.time()
        self.timer.configure(text="00:00:00")
        self.warned = False
        self.set_state("on")

    def _tick_meters(self):
        now = time.time()
        self.app_open_lbl.configure(
            text=f"Uygulama açık {d.fmt_hms(now - self.opened_at)}")
        if self._state == "on":
            self.timer.configure(text=d.fmt_hms(now - self.started_at))
        m = self.net.sample() if self._state != "off" else self.net.last
        total = m["total"]
        limit = d.pick_limit(total)
        self.data_total.configure(text=d.fmt_bytes(total))
        self.data_limit.configure(text=f"/ {d.fmt_bytes(limit, 0)}")
        self.data_detail.configure(
            text=f"↓ {d.fmt_bytes(m['down'])}    ↑ {d.fmt_bytes(m['up'])}    "
                 f"{d.fmt_bytes(m['rate'])}/s")
        self.data_bar.set(min(1.0, total / limit))
        self.data_src.configure(
            text="tüm ağ trafiği" if self.net.source == "sistem"
            else "yalnızca uygulama üzerinden")

    def _poll_once(self):
        self._drain_checks()
        try:
            while True:
                self.log_line(self.q.get_nowait())
        except queue.Empty:
            pass

        try:
            while True:
                name = self._done.get_nowait()
                self._set_tools("normal")
                if name == "auto" and self._auto_res:
                    self.profile.set("Otomatik")
                    self.info.configure(text=INFO["Otomatik"])
                    msg = ("Çalışan yöntem bulundu ve 'Otomatik' profili seçildi.")
                    if self.running():
                        msg += " Uygulamak için DURDUR → BAŞLAT."
                    self.log_line(msg)
        except queue.Empty:
            pass

        for k, lbl in self.stat_labels.items():
            lbl.configure(text=str(d.STATS.get(k, 0)))
        self._tick_meters()

        if self.engine is not None:
            alive = self.engine.alive()
            if not alive and self._state != "off":
                self.set_state("off")
            elif (alive and not self.warned and SYSTEM == "Windows"
                  and time.time() - self.started_at > 25
                  and d.STATS["hello"] == 0):
                self.warned = True
                self.log_line(
                    "İpucu: 25 sn'dir hiç TLS bağlantısı yakalanmadı. Tarayıcı "
                    "bir VPN/proxy kullanıyor olabilir; siteyi yeniden aç.")
            elif (alive and not self.warned and SYSTEM == "Darwin"
                  and time.time() - self.started_at > 25
                  and d.STATS["conn"] == 0):
                self.warned = True
                self.log_line(
                    "İpucu: 25 sn'dir hiç bağlantı gelmedi. \"macOS sistem "
                    "proxy'si\" anahtarı açık mı? Tarayıcıyı yeniden başlatmayı "
                    "da dene (bazı tarayıcılar proxy'yi açılışta okur).")

    def poll(self):
        try:
            self._poll_once()
        except Exception as e:  # bir hata arayuz guncellemesini durdurmasin
            try:
                self.log_line(f"[!] arayüz: {e!r}")
            except Exception:
                pass
        self.after(250, self.poll)

    def on_close(self):
        if self.running():
            self.engine.stop()
            # sistem proxy'si kapansin (macOS'ta doğrulama birkaç sn sürebilir)
            self.engine.thread.join(timeout=12 if SYSTEM == "Darwin" else 3)
        self.destroy()


def crash_log(text):
    try:
        path = os.path.join(os.path.expanduser("~"), "ProjectSieRra_hata.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        return path
    except Exception:
        return None


def main():
    try:
        ensure_admin_windows()
        App().mainloop()
    except SystemExit as e:
        if e.code not in (None, 0):
            crash_log(str(e.code))
        raise
    except Exception:
        path = crash_log(traceback.format_exc())
        if SYSTEM == "Windows":
            ctypes.windll.user32.MessageBoxW(
                None, f"Project : SieRra baslatilamadi.\nAyrinti: {path}",
                "Project : SieRra", 0x10)
        elif SYSTEM == "Darwin":
            msg = f"Başlatılamadı. Ayrıntı: {path}".replace('"', "'")
            try:
                subprocess.run(["/usr/bin/osascript", "-e",
                                f'display alert "Project : SieRra" '
                                f'message "{msg}" as critical'], timeout=60)
            except Exception:
                pass
        raise


if __name__ == "__main__":
    main()
