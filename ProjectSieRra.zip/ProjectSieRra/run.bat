@echo off
setlocal
cd /d "%~dp0"

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY goto nopython
%PY% --version >nul 2>&1
if errorlevel 1 goto nopython

echo Gerekli paketler kontrol ediliyor...
%PY% -m pip install --quiet --disable-pip-version-check pydivert customtkinter psutil
if errorlevel 1 (
    echo Paket kurulumu basarisiz. Internet baglantini kontrol et.
    pause
    exit /b 1
)

echo Project : SieRra baslatiliyor (yonetici izni isteyecek)...
%PY% dpibypass_gui.py
if errorlevel 1 (
    echo.
    echo Uygulama hata ile kapandi. Ayrinti: %USERPROFILE%\ProjectSieRra_hata.txt
    pause
)
exit /b 0

:nopython
echo Python bulunamadi. https://www.python.org/downloads/ adresinden kur.
echo Kurulumda "Add python.exe to PATH" ve "tcl/tk and IDLE" secenekleri ACIK olmali.
pause
exit /b 1
