#!/bin/bash
# Project : SieRra - macOS .app üretir (build.bat'ın karşılığı).
# Uygulamayı çalıştıracağın Mac'te derle (Intel / Apple Silicon mimarisi için).
cd "$(dirname "$0")" || exit 1
. ./mac_common.sh

LOG="$PWD/build_log.txt"
APP_NAME="ProjectSieRra"          # dosya adı (iki nokta üst üste Finder'da sorun çıkarır)
APP_TITLE="Project : SieRra"       # ekranda görünen ad
echo "Project : SieRra macOS build" > "$LOG"

pause() { read -n 1 -s -r -p "Kapatmak için bir tuşa bas..."; echo; }
fail() {
  echo
  echo "HATA oluştu. Son satırlar (tamamı: build_log.txt):"
  echo "----------------------------------------------"
  tail -n 25 "$LOG"
  echo "----------------------------------------------"
  echo ".app olmadan denemek için: run.command"
  pause; exit 1
}

echo "=============================================="
echo "  $APP_TITLE - .app oluşturuluyor"
echo "=============================================="

if ! find_python; then no_python; pause; exit 1; fi
echo "Python: $PY" | tee -a "$LOG"

echo "[1/3] Paketler kuruluyor (ilk seferde birkaç dakika sürebilir)..."
setup_venv pyinstaller customtkinter certifi psutil >>"$LOG" 2>&1 || fail

echo "[2/3] .app derleniyor (1-3 dakika)..."
"$VENV/bin/python" -m PyInstaller --noconfirm --clean ProjectSieRra_mac.spec >>"$LOG" 2>&1 || fail

echo "[3/3] İmzalanıyor ve kontrol ediliyor..."
APP="dist/$APP_NAME.app"
[ -d "$APP" ] || fail
# Ad-hoc imza: Apple Silicon'da imzasız uygulama açılmaz, Intel'de zararsızdır.
codesign --force --deep --sign - "$APP" >>"$LOG" 2>&1 || echo "(codesign uyarısı: build_log.txt)"
rm -rf "./$APP_NAME.app"
cp -R "$APP" "./$APP_NAME.app" || fail

echo
echo "BİTTİ!  Uygulama: $PWD/$APP_NAME.app"
open -R "$PWD/$APP_NAME.app"
pause
