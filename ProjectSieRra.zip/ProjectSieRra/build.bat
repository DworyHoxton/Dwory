@echo off
setlocal
cd /d "%~dp0"
set "LOG=%~dp0build_log.txt"
echo Project : SieRra build > "%LOG%"

echo ==============================================
echo   Project : SieRra - exe olusturuluyor
echo ==============================================
echo.

rem --- Python'u bul
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY goto nopython
%PY% --version >>"%LOG%" 2>&1
if errorlevel 1 goto nopython

rem --- Defender istisnasi (istege bagli, yonetici gerekir)
net session >nul 2>&1
if errorlevel 1 goto noadmin
echo Windows Defender, bu tur araclari (WinDivert surucusu) yanlislikla silebilir.
set "ANS="
set /p "ANS=Bu klasor icin Defender istisnasi eklensin mi? [E/H]: "
if /i "%ANS%"=="E" powershell -NoProfile -Command "Add-MpPreference -ExclusionPath '%~dp0'" >>"%LOG%" 2>&1
goto build
:noadmin
echo (Not: build.bat'a sag tik ^> Yonetici olarak calistir dersen Defender
echo  istisnasi eklenebilir; exe silinirse bu gerekir.)

:build
echo.
echo [1/3] Paketler kuruluyor (ilk seferde birkac dakika surebilir)...
%PY% -m pip install --upgrade pip pyinstaller pydivert customtkinter psutil >>"%LOG%" 2>&1
if errorlevel 1 goto err

echo [2/3] exe derleniyor (1-3 dakika)...
%PY% -m PyInstaller --noconfirm --clean --onefile --noconsole --uac-admin --collect-all pydivert --collect-all customtkinter --hidden-import psutil --version-file version.txt --name ProjectSieRra dpibypass_gui.py >>"%LOG%" 2>&1
if errorlevel 1 goto err

echo [3/3] Kontrol ediliyor...
timeout /t 3 /nobreak >nul
if not exist "dist\ProjectSieRra.exe" goto missing
copy /y "dist\ProjectSieRra.exe" "%~dp0ProjectSieRra.exe" >nul
timeout /t 2 /nobreak >nul
if not exist "%~dp0ProjectSieRra.exe" goto missing

echo.
echo BITTI!  Dosya: %~dp0ProjectSieRra.exe
start "" explorer /select,"%~dp0ProjectSieRra.exe"
pause
exit /b 0

:missing
echo.
echo exe olusturuldu ama dosya kayboldu: buyuk ihtimalle virus korumasi sildi.
echo  1) Windows Guvenligi ^> Virus ve tehdit korumasi ^> Koruma gecmisi
echo     bolumunden dosyayi geri yukle.
echo  2) Bu klasoru istisnalara ekle (Virus ve tehdit korumasi ayarlari ^>
echo     Dislamalar), sonra build.bat'i tekrar calistir.
echo  3) exe istemiyorsan: run.bat ile dogrudan calistirabilirsin.
pause
exit /b 1

:nopython
echo.
echo Python bulunamadi. https://www.python.org/downloads/ adresinden kur.
echo Kurulumda "Add python.exe to PATH" ve "tcl/tk and IDLE" secenekleri ACIK olmali.
echo (Microsoft Store'daki Python kisayolu calismaz; python.org surumunu kullan.)
pause
exit /b 1

:err
echo.
echo HATA olustu. Son satirlar (tamami: build_log.txt):
echo ----------------------------------------------
powershell -NoProfile -Command "Get-Content -Tail 25 '%LOG%'"
echo ----------------------------------------------
echo Bu cikti ile bana yazarsan duzeltirim. exe olmadan denemek icin: run.bat
pause
exit /b 1
